--[[
	Auctioneer Addon for World of Warcraft(tm).
	Version: 3.6.1 (Platypus)
	Revision: $Id: AuctioneerUI.lua 735 2006-03-03 04:04:26Z vindicator $

	Auctioneer UI manager

	License:
		This program is free software; you can redistribute it and/or
		modify it under the terms of the GNU General Public License
		as published by the Free Software Foundation; either version 2
		of the License, or (at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program(see GPL.txt); if not, write to the Free Software
		Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
]]

-------------------------------------------------------------------------------
-- Data members
-------------------------------------------------------------------------------
CursorItem = nil;

MoneyTypeInfo["AUCTIONEER"] = {
	UpdateFunc = function()
		return this.staticMoney;
	end,

	collapse = 1,
	fixedWidth = 1,
	showSmallerCoins = 1
};

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctioneerUI_OnLoad()
	Stubby.RegisterFunctionHook("PickupContainerItem", 200, AuctioneerUI_PickupContainerItemHook)
end

-------------------------------------------------------------------------------
-- Called after Blizzard's AuctionFrameTab_OnClick() method.
-------------------------------------------------------------------------------
function AuctioneerUI_AuctionFrameTab_OnClickHook(_, _, index)
	-- Clicking Browse on the way from Post Auctions (still shown at this point) with an item in
	-- the slot shows that item's auctions, so the suggested price can be checked against what's
	-- for sale ("post-browse"). Only a click on the tab itself, which passes no index: opening
	-- the AH and Alt+Right-click searches switch to Browse with index 1. (Auctioneer-OctoWoW)
	local postItem = nil;
	if (not index and AuctionFramePost:IsVisible()) then postItem = AuctionFramePost:GetItemName(); end

	if (not index) then
		index = this:GetID();
	end

	-- Hide the Auctioneer tabs
	AuctionFrameSearch:Hide();
	AuctionFramePost:Hide();
	
	-- Show an Auctioneer tab if its the one clicked
	local tab = getglobal("AuctionFrameTab"..index);
	if (tab) then
		if (tab:GetName() == "AuctionFrameTabSearch") then
			AuctionFrameTopLeft:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-TopLeft");
			AuctionFrameTop:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-Top");
			AuctionFrameTopRight:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-TopRight");
			AuctionFrameBotLeft:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-BotLeft");
			AuctionFrameBot:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-Bot");
			AuctionFrameBotRight:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-BotRight");
			AuctionFrameSearch:Show();
		elseif (tab:GetName() == "AuctionFrameTabPost") then
			AuctionFrameTopLeft:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-TopLeft");
			AuctionFrameTop:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-Top");
			AuctionFrameTopRight:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-TopRight");
			AuctionFrameBotLeft:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-BotLeft");
			AuctionFrameBot:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-Bot");
			AuctionFrameBotRight:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-BotRight");
			AuctionFramePost:Show();
		end
	end

	if (postItem and AuctionFrameBrowse:IsVisible() and Auctioneer.Command.GetFilter('post-browse')) then
		Auctioneer.Scanning.ShowItemOnBrowse(postItem);
	end
end

-------------------------------------------------------------------------------
-- Called after Blizzard's PickupContainerItem() method in order to capture
-- which item is on the cursor.
-------------------------------------------------------------------------------
function AuctioneerUI_PickupContainerItemHook(_, _, bag, slot)
	if (CursorHasItem()) then
		CursorItem = { bag = bag, slot = slot };
		--EnhTooltip.DebugPrint("Picked up item "..CursorItem.bag..", "..CursorItem.slot);
	else
		CursorItem = nil;
		--EnhTooltip.DebugPrint("Dropped item "..bag..", "..slot);
	end
	AuctioneerUI_GetCursorContainerItem();
end

-------------------------------------------------------------------------------
-- Gets the bag and slot number of the item on the cursor.
-------------------------------------------------------------------------------
function AuctioneerUI_GetCursorContainerItem()
	if (CursorHasItem() and CursorItem) then
		return CursorItem;
	end
	return nil;
end

-------------------------------------------------------------------------------
-- Marking several auctions (Auctioneer-OctoWoW), on the Browse, Bids and Auctions tabs:
-- Shift-click marks or unmarks an auction, and Alt-click marks every auction from the last one
-- clicked to this one (Cmd on a Mac keyboard, if the game gets it as Alt; WoW only knows Shift,
-- Ctrl and Alt). Bid and Buyout, or Cancel Auction, then do them all after one confirmation.
-- A plain click selects one, as before. (The Search Auctions tab does the same with its own
-- list, see AuctionFrameSearch.lua.)
-- Marks are list positions with each auction's details; a mark is dropped when the auction at
-- its position changes (bought, sold, cancelled, bid on, the list renumbered), and a new search,
-- another page, sorting or leaving the tab clears them. The bids and cancels go out one at a
-- time, a moment apart, each auction found again by its details, since the list renumbers after
-- each one. Each mark is used once, so a batch never buys more auctions than were marked.
-------------------------------------------------------------------------------
local ACTION_INTERVAL = 0.2;
-- each list: "list" on Browse, "bidder" on Bids, "owner" on Auctions
local lMarks = {
	list = { scroll = "BrowseScrollFrame", rows = "BrowseButton", rowCount = "NUM_BROWSE_TO_DISPLAY",
		update = "AuctionFrameBrowse_Update", click = "BrowseButton_OnClick", tab = "AuctionFrameBrowse",
		bid = "BrowseBidButton", buyout = "BrowseBuyoutButton", price = "BrowseBidPrice" },
	bidder = { scroll = "BidScrollFrame", rows = "BidButton", rowCount = "NUM_BIDS_TO_DISPLAY",
		update = "AuctionFrameBid_Update", click = "BidButton_OnClick", tab = "AuctionFrameBid",
		bid = "BidBidButton", buyout = "BidBuyoutButton", price = "BidBidPrice" },
	owner = { scroll = "AuctionsScrollFrame", rows = "AuctionsButton", rowCount = "NUM_AUCTIONS_TO_DISPLAY",
		update = "AuctionFrameAuctions_Update", click = "AuctionsButton_OnClick", tab = "AuctionFrameAuctions" },
};
for _, l in pairs(lMarks) do
	l.marked = {};			-- list position -> details of the auction marked there
	l.sent = {};			-- positions bid on or cancelled since the list last changed
	-- Blizzard's own single selection counts only after a plain click: Shift-clicks and doing the
	-- marked ones leave it pointing at an auction that was unmarked or has moved, which its own
	-- Bid, Buyout or Cancel Auction would then act on
	l.trusted = true;
	-- the auction last clicked or Shift-clicked, where an Alt-click range starts, with its details
	-- so a renumbered list doesn't start a range somewhere else
	l.anchor, l.anchorDetails = nil, nil;
end
local LIST_EVENTS = { AUCTION_ITEM_LIST_UPDATE = "list", AUCTION_BIDDER_LIST_UPDATE = "bidder", AUCTION_OWNED_LIST_UPDATE = "owner" };
local DONE = { cancel = "cancelled", bid = "bid on", buyout = "bought out" };
local lQueue = {};			-- { kind, details, action } for each auction still to bid on or cancel
local lQueueTimer, lQueueSkipped = 0, 0;

local function auctionDetails(kind, index)
	local name, _, count, _, _, _, minBid, _, buyout, bidAmount, _, owner = GetAuctionItemInfo(kind, index);
	if (not name) then return nil; end
	return name.."|"..count.."|"..minBid.."|"..buyout.."|"..bidAmount.."|"..(owner or "");
end

local function auctions(count)
	if (count == 1) then return "1 auction"; end
	return count.." auctions";
end

-- The deposit an auction cost, for the cancel warning. The game doesn't say once it's posted,
-- so it's noted as you post (AuctioneerUI_RecordDepositHook), per realm and character, for a
-- few days. One posted before that is worked out from the item's vendor price and the time
-- left: Very Long means a 24 hour auction; otherwise it may have started longer than it looks,
-- so it's the smallest it could have been. Returns the deposit and whether it's exact, or nil.
local DEPOSIT_KEEP = 3 * 24 * 60 * 60;
local function depositKey(name, count, minBid, buyout)
	return Auctioneer.Util.GetAuctionKey().."|"..UnitName("player").."|"..name.."|"..count.."|"..minBid.."|"..buyout;
end

function AuctioneerUI_RecordDepositHook(_, _, minBid, buyout, duration)
	local name, _, count = GetAuctionSellItemInfo();
	if (not name or not count or not minBid or not duration or not CalculateAuctionDeposit) then return; end
	if (not AuctionConfig.deposits) then AuctionConfig.deposits = {}; end
	local now = time();
	for key, entry in pairs(AuctionConfig.deposits) do
		local _, _, at = string.find(entry, ";(%d+)$");
		if (not at or now - tonumber(at) > DEPOSIT_KEEP) then AuctionConfig.deposits[key] = nil; end
	end
	AuctionConfig.deposits[depositKey(name, count, minBid, buyout or 0)] = CalculateAuctionDeposit(duration)..";"..now;
end

function AuctioneerUI_AuctionDeposit(index)
	local name, _, count, _, _, _, minBid, _, buyout = GetAuctionItemInfo("owner", index);
	if (not name) then return nil; end
	local recorded = AuctionConfig.deposits and AuctionConfig.deposits[depositKey(name, count, minBid, buyout)];
	if (recorded) then
		local _, _, deposit = string.find(recorded, "^(%d+);");
		if (deposit) then return tonumber(deposit), true; end
	end
	local link = GetAuctionItemLink("owner", index);
	local itemID = link and EnhTooltip.BreakLink(link);
	if (not itemID or not AuctionFramePost_CalculateAuctionDeposit) then return nil; end
	local timeLeft = GetAuctionItemTimeLeft("owner", index);
	local duration = 120;
	if (timeLeft == 4) then duration = 1440; elseif (timeLeft == 3) then duration = 480; end
	local deposit = AuctionFramePost_CalculateAuctionDeposit(itemID, count, duration);
	if (not deposit) then return nil; end
	return deposit, (timeLeft == 4);
end

-- the warning's words: the marked auctions, their deposits and whether there's a bid cost
function AuctioneerUI_CancelWarningText(count, cost)
	local deposits, known, exact = 0, 0, true;
	for index in pairs(lMarks.owner.marked) do
		local deposit, isExact = AuctioneerUI_AuctionDeposit(index);
		if (deposit) then
			deposits = deposits + deposit;
			known = known + 1;
			if (not isExact) then exact = false; end
		else
			exact = false;
		end
	end
	local amount = "";
	if (known > 0) then
		amount = string.gsub(EnhTooltip.GetTextGSC(deposits, true, true), "%s+$", "");
		if (amount == "0") then amount = "0c"; end
		if (not exact) then amount = "at least "..amount; end
		amount = " ("..amount..")";
	end
	local text;
	if (count == 1) then
		text = "Cancel this auction? You lose its deposit"..amount;
	else
		text = "Cancel these "..count.." auctions? You lose their deposits"..amount;
	end
	if (cost == 0) then
		return text..".";
	elseif (count == 1) then
		return text..", and its bid costs you:";
	end
	return text..", and the bids on them cost you:";
end

-- how many marks are still on the auction they were put on, dropping the others
local function markedCount(kind)
	local marked, count = lMarks[kind].marked, 0;
	for index, details in pairs(marked) do
		if (auctionDetails(kind, index) == details) then count = count + 1; else marked[index] = nil; end
	end
	return count;
end

-- the confirmation showing, for bidding on or buying out the marked auctions of one list (see
-- AuctioneerUI_ConfirmBids)
local lConfirm = nil;
function AuctioneerUI_HideConfirm(kind)
	if (lConfirm and lConfirm.kind == kind) then StaticPopup_Hide("AUCTIONEER_BUY_AUCTIONS"); end
end

local function clearMarks(kind)
	local marked = lMarks[kind].marked;
	if (next(marked)) then AuctioneerUI_HideConfirm(kind); end
	for index in pairs(marked) do marked[index] = nil; end
end

-- your marked auctions, and what cancelling them costs (5% of each bid, as for one)
function AuctioneerUI_MarkedAuctions()
	local count, cost = markedCount("owner"), 0;
	for index in pairs(lMarks.owner.marked) do
		local _, _, _, _, _, _, _, _, _, bidAmount = GetAuctionItemInfo("owner", index);
		cost = cost + math.floor(bidAmount * 0.05);
	end
	return count, cost;
end

-- Blizzard's single selection, if it still counts: picked by a plain click, and still on the
-- auction clicked (the list renumbers when auctions sell or are cancelled, and the selection
-- stays on the position)
local function trustedSelection(kind)
	local l, selected = lMarks[kind], GetSelectedAuctionItem(kind);
	if (l.trusted and selected and selected > 0 and selected == l.anchor and auctionDetails(kind, selected) == l.anchorDetails) then
		return selected;
	end
	return nil;
end

-- On Browse, whether the list shows the auction: not one hidden while it shows one item only
-- (see AHScanning.lua), so a range doesn't take in auctions you can't see
local function rowShown(kind, index)
	local only = (kind == "list" and Auctioneer.Scanning and Auctioneer.Scanning.GetBrowseOnlyName and Auctioneer.Scanning.GetBrowseOnlyName());
	return (not only or GetAuctionItemInfo(kind, index) == only);
end

-- before Blizzard's row click (BrowseButton_OnClick, BidButton_OnClick, AuctionsButton_OnClick):
-- a Shift-click marks or unmarks the row instead, and an Alt-click marks a range
local function rowClick(kind, button)
	local l = lMarks[kind];
	local index = button:GetID() + FauxScrollFrame_GetOffset(getglobal(l.scroll));
	local shift, alt = IsShiftKeyDown(), IsAltKeyDown();
	if (not shift and not alt) then
		clearMarks(kind);
		l.trusted = true;
		l.anchor, l.anchorDetails = index, auctionDetails(kind, index);
		return;
	end
	-- the auction selected before counts as the first mark
	local selected = trustedSelection(kind);
	if (markedCount(kind) == 0 and selected and selected ~= index) then
		l.marked[selected] = auctionDetails(kind, selected);
	end
	l.trusted = false;
	if (alt and l.anchor and auctionDetails(kind, l.anchor) == l.anchorDetails) then
		for i = math.min(l.anchor, index), math.max(l.anchor, index) do
			if (rowShown(kind, i)) then l.marked[i] = auctionDetails(kind, i); end
		end
	elseif (l.marked[index]) then
		l.marked[index] = nil;
		l.anchor, l.anchorDetails = index, auctionDetails(kind, index);
	else
		l.marked[index] = auctionDetails(kind, index);
		l.anchor, l.anchorDetails = index, auctionDetails(kind, index);
	end
	CloseAuctionStaticPopups();
	StaticPopup_Hide("AUCTIONEER_CANCEL_AUCTIONS");
	StaticPopup_Hide("AUCTIONEER_BUY_AUCTIONS");
	getglobal(l.update)();
	return "abort";
end

-- the marked rows lit (rows' IDs plus the offset are their list positions, also while Browse
-- shows one item only)
local function litRows(kind)
	local l = lMarks[kind];
	local offset = FauxScrollFrame_GetOffset(getglobal(l.scroll));
	for i = 1, getglobal(l.rowCount) do
		local button = getglobal(l.rows..i);
		if (l.marked[button:GetID() + offset]) then button:LockHighlight(); else button:UnlockHighlight(); end
	end
end

-- What bidding on, or buying out, the auction at a position takes now, and what it costs you (a
-- buyout of one you're the high bidder on costs the rest, as Blizzard reckons it); nil if it
-- can't be done: your own, no buyout, or already your bid
local function bidPrice(kind, index, action)
	local name, _, _, _, _, _, minBid, minIncrement, buyout, bidAmount, highBidder, owner = GetAuctionItemInfo(kind, index);
	if (not name or owner == UnitName("player")) then return nil; end
	if (action == "buyout") then
		if (buyout <= 0 or buyout < minBid or buyout < bidAmount) then return nil; end
		if (highBidder) then return buyout, buyout - bidAmount; end
		return buyout, buyout;
	end
	if (highBidder) then return nil; end
	local bid = minBid;
	if (bidAmount > 0) then bid = bidAmount + minIncrement; end
	if (MAXIMUM_BID_PRICE and bid > MAXIMUM_BID_PRICE) then return nil; end
	return bid, bid;
end

-- the marked auctions an action can be done on, and what doing it costs in all
local function markedFor(kind, action)
	local count, cost = 0, 0;
	for index in pairs(lMarks[kind].marked) do
		local _, price = bidPrice(kind, index, action);
		if (price) then
			count = count + 1;
			cost = cost + price;
		end
	end
	return count, cost;
end

local function buttonText(text, count)
	if (count > 1) then return text.." ("..count..")"; end
	return text;
end

-- after Blizzard's Browse and Bids updates: the marked rows lit, Bid and Buyout counting them,
-- and the bid box showing what the bids come to
local function bidsUpdate(kind)
	local l = lMarks[kind];
	local bidButton, buyoutButton = getglobal(l.bid), getglobal(l.buyout);
	local bids, buys = 0, 0;
	if (markedCount(kind) > 0 or not l.trusted) then
		litRows(kind);
		local bidCost;
		bids, bidCost = markedFor(kind, "bid");
		buys = markedFor(kind, "buyout");
		if (bids > 0) then
			bidButton:Enable();
			MoneyInputFrame_SetCopper(getglobal(l.price), bidCost);
		else
			bidButton:Disable();
		end
		if (buys > 0) then buyoutButton:Enable(); else buyoutButton:Disable(); end
	end
	bidButton:SetText(buttonText(BID, bids));
	buyoutButton:SetText(buttonText(BUYOUT, buys));
end

-- after Blizzard's AuctionFrameAuctions_Update: the marked rows lit, the Cancel button counting them
function AuctioneerUI_AuctionsUpdateHook()
	local count = markedCount("owner");
	if (count > 0 or not trustedSelection("owner")) then
		litRows("owner");
		if (count > 0) then
			AuctionsCancelAuctionButton:Enable();
		else
			AuctionsCancelAuctionButton:Disable();
		end
	end
	if (count > 1) then
		AuctionsCancelAuctionButton:SetText("Cancel "..count.." Auctions");
	else
		AuctionsCancelAuctionButton:SetText(CANCEL_AUCTION);
	end
end

-- One confirmation for bidding on or buying out the marked auctions, on any tab: what they cost
-- in all, and Accept only if you have that much. kind is the list they're on ("search" for
-- Search Auctions), and run does them once accepted.
function AuctioneerUI_ConfirmBids(kind, action, count, cost, run)
	local text;
	if (action == "buyout") then
		if (count == 1) then text = "Buy out this auction for:"; else text = "Buy out these "..count.." auctions for:"; end
	elseif (count == 1) then
		text = "Bid on this auction for:";
	else
		text = "Bid on these "..count.." auctions for:";
	end
	StaticPopup_Hide("AUCTIONEER_BUY_AUCTIONS");
	lConfirm = { kind = kind, text = text, cost = cost, run = run };
	StaticPopup_Show("AUCTIONEER_BUY_AUCTIONS");
end

-- the marked auctions that can still be done, queued; the marks cleared
function AuctioneerUI_DoMarked(kind, action)
	local l = lMarks[kind];
	-- earlier sends only count while a batch is still going: the list may not have changed yet
	if (table.getn(lQueue) == 0) then l.sent = {}; end
	local count = 0;
	for index, details in pairs(l.marked) do
		if (auctionDetails(kind, index) == details and (action == "cancel" or bidPrice(kind, index, action))) then
			table.insert(lQueue, { kind = kind, details = details, action = action });
			count = count + 1;
		end
		l.marked[index] = nil;
	end
	l.trusted = false;
	if (count == 0) then
		getglobal(l.update)();
		return;
	end
	lQueueTimer = 0;
	if (action == "cancel") then
		Auctioneer.Util.ChatPrint("Auctioneer: cancelling "..auctions(count).."...");
	elseif (action == "buyout") then
		Auctioneer.Util.ChatPrint("Auctioneer: buying out "..auctions(count).."...");
	else
		Auctioneer.Util.ChatPrint("Auctioneer: bidding on "..auctions(count).."...");
	end
	AuctioneerActionQueueFrame:Show();
	getglobal(l.update)();
end

-- Bid or Buyout with auctions marked: one confirmation for all of them. Returns whether there
-- were marks, so Blizzard's own button doesn't act on its selection as well.
local function confirmMarked(kind, action)
	if (markedCount(kind) == 0) then return false; end
	local count, cost = markedFor(kind, action);
	if (count > 0) then
		AuctioneerUI_ConfirmBids(kind, action, count, cost, function() AuctioneerUI_DoMarked(kind, action); end);
	end
	return true;
end

local function queueStopped(why, kinds)
	local left = {};
	for i = table.getn(lQueue), 1, -1 do
		local action = lQueue[i].action;
		if (kinds[action]) then
			left[action] = (left[action] or 0) + 1;
			table.remove(lQueue, i);
		end
	end
	for action, count in pairs(left) do
		if (count == 1) then
			Auctioneer.Util.ChatPrint("Auctioneer: "..why..", so 1 of the auctions wasn't "..DONE[action]..".");
		else
			Auctioneer.Util.ChatPrint("Auctioneer: "..why..", so "..count.." of the auctions weren't "..DONE[action]..".");
		end
	end
end

-- one bid or cancel per tick, while the auction house is open
function AuctioneerUI_ActionQueueOnUpdate(elapsed)
	lQueueTimer = lQueueTimer - (elapsed or 0);
	if (lQueueTimer > 0) then return; end
	lQueueTimer = ACTION_INTERVAL;
	local entry = lQueue[1];
	if (not entry) then
		if (lQueueSkipped == 1) then
			Auctioneer.Util.ChatPrint("Auctioneer: 1 of the marked auctions had changed or was gone, so it was left.");
		elseif (lQueueSkipped > 1) then
			Auctioneer.Util.ChatPrint("Auctioneer: "..lQueueSkipped.." of the marked auctions had changed or were gone, so they were left.");
		end
		lQueueSkipped = 0;
		AuctioneerActionQueueFrame:Hide();
		return;
	end
	if (not (AuctionFrame and AuctionFrame:IsVisible())) then
		queueStopped("the auction house closed", DONE);
		lQueueSkipped = 0;
		AuctioneerActionQueueFrame:Hide();
		return;
	end
	-- a bid waits for the server's answer to the one before, as Auctioneer's bid manager does
	-- (it gives up on one that isn't answered in a while, see AucBidManager.lua)
	if (entry.action ~= "cancel" and AucBidManager and AucBidManager.IsBidInProgress and AucBidManager.IsBidInProgress()) then
		return;
	end
	table.remove(lQueue, 1);
	local kind = entry.kind;
	local sent = lMarks[kind].sent;
	for index = 1, GetNumAuctionItems(kind) do
		if (not sent[index] and auctionDetails(kind, index) == entry.details) then
			if (entry.action == "cancel") then
				sent[index] = true;
				CancelAuction(index);
				return;
			end
			local amount, cost = bidPrice(kind, index, entry.action);
			if (amount and cost > GetMoney()) then
				table.insert(lQueue, 1, entry);
				queueStopped("you're out of money", { bid = true, buyout = true });
				return;
			end
			if (amount) then
				sent[index] = true;
				PlaceAuctionBid(kind, index, amount);
				return;
			end
			break;
		end
	end
	-- gone already (bought, sold, cancelled some other way), or changed
	lQueueSkipped = lQueueSkipped + 1;
end

-- Blizzard's rows pass a Shift-click on to the row click only on the Bids and Auctions rows
-- themselves: on Browse rows and on every item icon a Shift-click links the item into chat, with
-- the chat box open, and otherwise does nothing. With the chat box closed it marks instead.
local function shiftClickMarks(kind)
	local l = lMarks[kind];
	for i = 1, getglobal(l.rowCount) do
		local row = getglobal(l.rows..i);
		for _, button in ipairs({ row, getglobal(l.rows..i.."Item") }) do
			local orig = button:GetScript("OnClick");
			button:SetScript("OnClick", function()
				if (IsShiftKeyDown() and not IsControlKeyDown() and not ChatFrameEditBox:IsVisible()) then
					getglobal(l.click)(row);
				elseif (orig) then
					orig();
				end
			end);
		end
	end
end

-- Bid and Buyout on Browse and Bids: the marked auctions if there are any, otherwise Blizzard's
-- own, for the auction selected
local function setupBidButtons(kind)
	local l = lMarks[kind];
	for _, action in ipairs({ "bid", "buyout" }) do
		local button, act = getglobal(l[action]), action;
		local orig = button:GetScript("OnClick");
		button:SetScript("OnClick", function()
			if (confirmMarked(kind, act)) then return; end
			if (l.trusted and orig) then orig(); end
		end);
	end
end

function AuctioneerUI_SetupMarking()
	if (AuctioneerActionQueueFrame) then return; end
	-- parented to UIParent, so it can tell when the AH has closed and stop
	local queue = CreateFrame("Frame", "AuctioneerActionQueueFrame", UIParent);
	queue:Hide();
	queue:SetScript("OnUpdate", function() AuctioneerUI_ActionQueueOnUpdate(arg1); end);
	-- a list changed: positions renumbered, so earlier sends don't count any more
	for listEvent in pairs(LIST_EVENTS) do queue:RegisterEvent(listEvent); end
	queue:SetScript("OnEvent", function()
		local kind = LIST_EVENTS[event];
		if (kind) then lMarks[kind].sent = {}; end
	end);

	StaticPopupDialogs["AUCTIONEER_CANCEL_AUCTIONS"] = {
		text = CANCEL_AUCTION_CONFIRMATION,
		button1 = ACCEPT,
		button2 = CANCEL,
		OnAccept = function() AuctioneerUI_DoMarked("owner", "cancel"); end,
		OnShow = function()
			local count, cost = AuctioneerUI_MarkedAuctions();
			MoneyFrame_Update(this:GetName().."MoneyFrame", cost);
			-- set here, like Blizzard's own warning: the popup takes its size after this
			getglobal(this:GetName().."Text"):SetText(AuctioneerUI_CancelWarningText(count, cost));
		end,
		hasMoneyFrame = 1,
		showAlert = 1,
		exclusive = 1,
		hideOnEscape = 1
	};
	StaticPopupDialogs["AUCTIONEER_BUY_AUCTIONS"] = {
		text = "",
		button1 = ACCEPT,
		button2 = CANCEL,
		OnAccept = function()
			local confirm = lConfirm;
			lConfirm = nil;
			if (confirm) then confirm.run(); end
		end,
		OnShow = function()
			local confirm = lConfirm;
			if (not confirm) then return; end
			MoneyFrame_Update(this:GetName().."MoneyFrame", confirm.cost);
			local text = confirm.text;
			if (confirm.cost > GetMoney()) then
				text = "You don't have enough money. "..text;
				getglobal(this:GetName().."Button1"):Disable();
			end
			getglobal(this:GetName().."Text"):SetText(text);
		end,
		-- the popup frames are shared: Accept is enabled again for the next one
		OnHide = function()
			lConfirm = nil;
			getglobal(this:GetName().."Button1"):Enable();
		end,
		hasMoneyFrame = 1,
		showAlert = 1,
		exclusive = 1,
		hideOnEscape = 1
	};

	for kind, l in pairs(lMarks) do
		local list, tab = kind, getglobal(l.tab);
		Stubby.RegisterFunctionHook(l.click, -50, function(_, _, button) return rowClick(list, button or this); end);
		shiftClickMarks(list);
		-- leaving the tab clears the marks
		local onHide = tab:GetScript("OnHide");
		tab:SetScript("OnHide", function()
			clearMarks(list);
			if (onHide) then onHide(); end
		end);
	end
	Stubby.RegisterFunctionHook("AuctionFrameBrowse_Update", 250, function() bidsUpdate("list"); end);
	Stubby.RegisterFunctionHook("AuctionFrameBid_Update", 200, function() bidsUpdate("bidder"); end);
	Stubby.RegisterFunctionHook("AuctionFrameAuctions_Update", 200, AuctioneerUI_AuctionsUpdateHook);
	setupBidButtons("list");
	setupBidButtons("bidder");
	-- a new search or page, or sorting: the marks were for positions in the list as it was
	Stubby.RegisterFunctionHook("QueryAuctionItems", -40, function() clearMarks("list"); end);
	Stubby.RegisterFunctionHook("SortAuctionItems", -40, function(_, _, kind) if (lMarks[kind]) then clearMarks(kind); end end);
	-- before the item leaves the auction slot: what posting it costs
	Stubby.RegisterFunctionHook("StartAuction", -100, AuctioneerUI_RecordDepositHook);
	AuctionsCancelAuctionButton:SetScript("OnClick", function()
		local selected = trustedSelection("owner");
		if (markedCount("owner") == 0 and selected) then
			-- one selected the usual way: the same warning, so it shows the deposit too
			lMarks.owner.marked[selected] = auctionDetails("owner", selected);
		end
		if (markedCount("owner") > 0) then
			StaticPopup_Show("AUCTIONEER_CANCEL_AUCTIONS");
		end
	end);
end

-------------------------------------------------------------------------------
-- Wrapper for UIDropDownMenu_SetSeletedID() that sets 'this' before calling
-- UIDropDownMenu_SetSelectedID().
-------------------------------------------------------------------------------
function AuctioneerDropDownMenu_SetSelectedID(dropdown, index)
	local oldThis = this;
	this = dropdown;
	local newThis = this;
	UIDropDownMenu_SetSelectedID(dropdown, index);
	-- Double check that the value of 'this' didn't change... this can screw us
	-- up and prevent the reason for this method!
	if (newThis ~= this) then
		EnhTooltip.DebugPrint("WARNING: The value of this changed during AuctioneerDropDownMenu_SetSelectedID()");
	end
	this = oldThis;
end

-------------------------------------------------------------------------------
-- Wrapper for UIDropDownMenu_Initialize() that sets 'this' before calling
-- UIDropDownMenu_Initialize().
-------------------------------------------------------------------------------
function AuctioneerDropDownMenu_Initialize(dropdown, func)
	-- Hide all the buttons to prevent any calls to Hide() inside
	-- UIDropDownMenu_Initialize() which will screw up the value of this.
	local button, dropDownList;
	for i = 1, UIDROPDOWNMENU_MAXLEVELS, 1 do
		dropDownList = getglobal("DropDownList"..i);
		if ( i >= UIDROPDOWNMENU_MENU_LEVEL or frame:GetName() ~= UIDROPDOWNMENU_OPEN_MENU ) then
			dropDownList.numButtons = 0;
			dropDownList.maxWidth = 0;
			for j=1, UIDROPDOWNMENU_MAXBUTTONS, 1 do
				button = getglobal("DropDownList"..i.."Button"..j);
				button:Hide();
			end
		end
	end

	-- Call the UIDropDownMenu_Initialize() after swapping in a value for 'this'.
	local oldThis = this;
	this = getglobal(dropdown:GetName().."Button");
	local newThis = this;
	UIDropDownMenu_Initialize(dropdown, func);
	-- Double check that the value of 'this' didn't change... this can screw us
	-- up and prevent the reason for this method!
	if (newThis ~= this) then
		EnhTooltip.DebugPrint("WARNING: The value of this changed during UIDropDownMenu_Initialize()");
	end
	this = oldThis;
end
