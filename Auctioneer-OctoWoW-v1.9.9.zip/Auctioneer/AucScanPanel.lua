--[[
	Auctioneer Addon for World of Warcraft(tm).
	Auctioneer-OctoWoW: the side scan panel

	A small window attached to the right of the auction house window. It shows what is being
	scanned and how far along it is, holds the Scan, Resume, Stop and Item Scan/Search controls,
	and drives the scan every frame, so scanning carries on while the other AH tabs are used
	(see Auctioneer.Scanning.DriveScan).

	License:
		This program is free software; you can redistribute it and/or
		modify it under the terms of the GNU General Public License
		as published by the Free Software Foundation; either version 2
		of the License, or (at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program(see GPL.txt); if not, write to the Free Software
		Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
]]

--Local function prototypes
local onUpdate, refresh, setLine, buildArt, artCoords, addArt, keepControlsOnTop;

-- the panel's text is refreshed a few times a second, the scan is driven every frame
-- the panel's clickable controls, kept above the panel itself (see keepControlsOnTop)
local CONTROLS = { "AuctioneerScanPanelStopButton", "AuctioneerScanPanelProgress", "BrowseScanButton",
	"BrowseResumeScanButton", "BrowseItemScanBox", "BrowseItemScanButton" };
local REFRESH_INTERVAL = 0.2;
local sinceRefresh = REFRESH_INTERVAL;

-- The panel is drawn with pieces of the auction house window's own art (the Browse tab's six
-- textures), so it looks like part of the AH. Pieces are given as where they go in the panel
-- (x0, y0, x1, y1 from its top left) and which part of the AH art they come from, in the AH
-- window's own pixel layout: 832 x 512, made of TopLeft (256 wide), Top (320, stretched from
-- 256) and TopRight (256) over BotLeft, Bot and BotRight, each 256 tall. A piece never crosses
-- from one texture into another.
local ART = "Interface\\AuctionFrame\\UI-AuctionFrame-Browse-";
local PANEL_WIDTH, PANEL_HEIGHT = 200, 433;
local ART_PIECES = {
	-- title bar: the riveted end before the close box, mirrored for the left end
	{ dst = { 0, 0, 18, 25 }, src = { 790, 13, 808, 38 }, mirror = true },
	{ dst = { 18, 0, 182, 25 }, src = { 100, 13, 240, 38 } },
	{ dst = { 182, 0, 200, 25 }, src = { 790, 13, 808, 38 } },
	-- left and right borders
	{ dst = { 0, 25, 14, 417 }, src = { 8, 110, 22, 250 } },
	{ dst = { 186, 25, 200, 417 }, src = { 818, 110, 832, 250 } },
	-- bottom border with its shadow
	{ dst = { 0, 417, 12, 433 }, src = { 8, 430, 20, 446 } },
	{ dst = { 12, 417, 190, 433 }, src = { 184, 430, 250, 446 } },
	{ dst = { 190, 417, 200, 433 }, src = { 822, 430, 832, 446 } },
	-- dark status pane, from the corners of the results list so it keeps its bevelled edge
	{ dst = { 14, 31, 84, 122 }, src = { 186, 100, 256, 191 }, layer = "BORDER" },
	{ dst = { 84, 31, 186, 122 }, src = { 720, 100, 822, 191 }, layer = "BORDER" },
	{ dst = { 14, 122, 84, 213 }, src = { 186, 314, 256, 405 }, layer = "BORDER" },
	{ dst = { 84, 122, 186, 213 }, src = { 720, 314, 822, 405 }, layer = "BORDER" },
};
-- the stone between the borders: a clean strip of the AH's header band, every other copy
-- flipped upside down so the copies join without a seam
local STONE_SRC, STONE_HEIGHT = { 300, 44, 520, 92 }, 48;

-- which texture an area of the AH art is in, and its texture coordinates there
function artCoords(src)
	local x0, y0, x1, y1 = src[1], src[2], src[3], src[4];
	local column, left, width = "Left", 0, 256;
	if (x0 >= 576) then
		column, left, width = "Right", 576, 256;
	elseif (x0 >= 256) then
		column, left, width = "", 256, 320;
	end
	local row, top = "Top", 0;
	if (y0 >= 256) then row, top = "Bot", 256; end
	return row..column, (x0 - left) / width, (x1 - left) / width, (y0 - top) / 256, (y1 - top) / 256;
end

function addArt(panel, dst, src, layer, mirror, flip)
	local name, u0, u1, v0, v1 = artCoords(src);
	if (mirror) then u0, u1 = u1, u0; end
	if (flip) then v0, v1 = v1, v0; end
	local texture = panel:CreateTexture(nil, layer or "BACKGROUND");
	texture:SetTexture(ART..name);
	texture:SetTexCoord(u0, u1, v0, v1);
	texture:SetWidth(dst[3] - dst[1]);
	texture:SetHeight(dst[4] - dst[2]);
	texture:SetPoint("TOPLEFT", panel, "TOPLEFT", dst[1], -dst[2]);
end

-- called once from the panel's OnLoad
function buildArt(panel)
	panel:SetWidth(PANEL_WIDTH);
	panel:SetHeight(PANEL_HEIGHT);
	local y, flip = 25, false;
	while (y < PANEL_HEIGHT - 16) do
		local height = math.min(STONE_HEIGHT, PANEL_HEIGHT - 16 - y);
		addArt(panel, { 14, y, PANEL_WIDTH - 14, y + height }, { STONE_SRC[1], STONE_SRC[2], STONE_SRC[3], STONE_SRC[2] + height }, "BACKGROUND", false, flip);
		y = y + height;
		flip = not flip;
	end
	for i = 1, table.getn(ART_PIECES) do
		local piece = ART_PIECES[i];
		addArt(panel, piece.dst, piece.src, piece.layer, piece.mirror, piece.flip);
	end
end

function setLine(name, text, r, g, b)
	local line = getglobal("AuctioneerScanPanel"..name);
	line:SetText(text or "");
	if (r) then line:SetTextColor(r, g, b); end
end

-- The panel takes the mouse, so clicks on it don't fall through to the game world. Moving it
-- onto the AH window can raise its frame level without raising its own children, which leaves
-- the Stop button underneath it: Stop looks usable, and the panel takes every click. Each
-- control is lifted back above the panel whenever it ends up level with or below it.
function keepControlsOnTop()
	local level = AuctioneerScanPanel:GetFrameLevel() + 1;
	for i = 1, table.getn(CONTROLS) do
		local control = getglobal(CONTROLS[i]);
		if (control and control:GetFrameLevel() < level) then
			control:SetFrameLevel(level);
		end
	end
end

function onUpdate(elapsed)
	keepControlsOnTop();
	Auctioneer.Scanning.DriveScan();
	sinceRefresh = sinceRefresh + (elapsed or 0);
	if (sinceRefresh < REFRESH_INTERVAL) then return; end
	sinceRefresh = 0;
	refresh();
end

function refresh()
	local status = Auctioneer.Scanning.GetScanStatus();
	local progress = getglobal("AuctioneerScanPanelProgress");
	local state, r, g, b, page, unit, speed, eta, hint;

	if (status.scanning) then
		if (status.itemScan) then state = "Item Scan running"; else state = "Scanning"; end
		r, g, b = 0.2, 1, 0.2;
		if (status.pages) then
			page = string.format("Page %d of %d", math.min(status.page, status.pages), status.pages);
			progress:SetValue(math.min(status.page, status.pages) / status.pages);
		else
			page = string.format("Page %d", status.page);
			progress:SetValue(0);
		end
		if (status.unit) then unit = string.format("Category %d of %d", status.unit, status.units); end
		if (status.elapsed and status.elapsed > 2 and status.seen > 0) then
			speed = string.format("%.1f auctions per second", status.seen / status.elapsed);
		end
		if (status.pages and status.elapsed and status.pagesDone > 0) then
			local left = (status.pages - status.page + 1) * status.elapsed / status.pagesDone;
			eta = "About "..SecondsToTime(math.max(left, 1)).." left";
			if (status.unit) then eta = eta.." in this one"; end
		end
		hint = "Other AH tabs stay usable while it scans. A search on Browse stops it.";
	else
		progress:SetValue(0);
		if (status.outcome == "finished") then
			state, r, g, b = "Finished", 1, 0.82, 0;
			progress:SetValue(1);
		elseif (status.outcome == "search") then
			state, r, g, b = "Stopped for your search", 1, 0.5, 0.25;
		elseif (status.outcome == "stopped") then
			state, r, g, b = "Stopped", 1, 0.5, 0.25;
		else
			state, r, g, b = "Ready", 1, 1, 1;
		end
		if (status.outcome and status.outcome ~= "finished") then
			if (status.canResume) then
				hint = "Resume carries on where it stopped.";
			elseif (status.label and string.sub(status.label, 1, 1) == "\"") then
				hint = "Press Item Scan to run it again.";
			end
		end
		if (not hint) then
			hint = "Scan covers the categories ticked in the Browse tab's list, or everything.";
		end
	end

	setLine("State", state, r, g, b);
	setLine("What", status.label or "");
	setLine("Page", page);
	setLine("Unit", unit);
	setLine("Speed", speed);
	setLine("Eta", eta);
	if (status.scanning or status.outcome) then
		setLine("Seen", string.format("Auctions seen: %d", status.seen));
	else
		setLine("Seen", "");
	end
	setLine("Hint", hint);
end

Auctioneer.ScanPanel = {
	OnUpdate = onUpdate,
	Refresh = refresh,
	KeepControlsOnTop = keepControlsOnTop,
	BuildArt = buildArt,
}
