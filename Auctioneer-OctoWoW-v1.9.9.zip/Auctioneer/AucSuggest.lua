--[[
	Auctioneer Addon for World of Warcraft(tm).
	Auctioneer-OctoWoW: item name suggestions

	Typing two or more letters in the Browse tab's Name box, or in a Search Auctions name box,
	drops down up to eight item names that start with them, or have a word that does. The names
	are every item Auctioneer has seen at the auction house. Reagents for this character's
	recipes that still give skill points come first (read from the profession windows by the
	Reagents boot code in Auctioneer.lua), then names that start with the letters, then items
	near the character's level, then the rest, most often seen first. Click a name to search for
	it, or press Tab to fill in the top one.

	License:
		This program is free software; you can redistribute it and/or
		modify it under the terms of the GNU General Public License
		as published by the Free Software Foundation; either version 2
		of the License, or (at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program(see GPL.txt); if not, write to the Free Software
		Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
]]

--Local function prototypes
local attach, update, show, accept, hide, hideSoon, reset, buildIndex, reagentWeights, createFrame, sortMatches, isPicked;

local MAX_ROWS = 8;
local ROW_HEIGHT = 16;
local MIN_LETTERS = 2;
-- after the box loses focus, so a click on a name still lands before the list goes
local HIDE_DELAY = 0.3;
-- recipe colours, by how much a recipe still gives: green, yellow, orange
local WEIGHT_COLORS = { { 0.25, 0.75, 0.25 }, { 1, 1, 0 }, { 1, 0.5, 0.25 } };

local lIndex = nil;		-- every item name seen at the AH, see buildIndex
local lFrame = nil;		-- the drop-down list
local lBox = nil;		-- the box it's showing for
local lMatches = {};
local lFilling = nil;	-- set while a name is put in the box, so that doesn't open the list again

-- Every item name Auctioneer has seen, from AuctionConfig.info ("category|name" per item key).
-- Each entry also caches its level, quality and how often it was seen once they're looked up.
function buildIndex()
	lIndex = {};
	local seen = {};
	for itemKey, info in pairs(AuctionConfig.info or {}) do
		local _, _, name = string.find(info, "|(.+)$");
		local _, _, id = string.find(itemKey, "^(%d+):");
		if (name and id and not seen[name]) then
			seen[name] = true;
			table.insert(lIndex, { name = name, lower = string.lower(name), id = tonumber(id), itemKey = itemKey });
		end
	end
end

-- rebuilt the next time it's needed, to take in items seen since (when the AH opens)
function reset()
	lIndex = nil;
	hide();
end

-- reagent name -> { weight = 1 to 3, skill = profession } over all this character's professions
function reagentWeights()
	local result = {};
	local all = Stubby.GetConfig("Auctioneer", "Reagents");
	if (type(all) ~= "table") then return result; end
	for skill, items in pairs(all) do
		for name, weight in pairs(items) do
			if (not result[name] or weight > result[name].weight) then
				result[name] = { weight = weight, skill = skill };
			end
		end
	end
	return result;
end

-- profession first, then names starting with the letters, then level, then the rest
function sortMatches(a, b)
	if (a.weight ~= b.weight) then return a.weight > b.weight; end
	if (a.starts ~= b.starts) then return a.starts; end
	if (a.tier ~= b.tier) then return a.tier < b.tier; end
	if (a.distance ~= b.distance) then return a.distance < b.distance; end
	if (a.seen ~= b.seen) then return a.seen > b.seen; end
	return a.lower < b.lower;
end

function update(box)
	local text = box:GetText() or "";
	if (not Auctioneer.Command.GetFilter('name-suggest') or string.len(text) < MIN_LETTERS or string.find(text, "|", 1, true)) then
		hide();
		return;
	end
	if (not lIndex) then buildIndex(); end
	local typed = string.lower(text);
	local length = string.len(typed);
	local reagents = reagentWeights();
	local level = UnitLevel("player");
	local data = AuctionConfig.data and AuctionConfig.data[Auctioneer.Util.GetAuctionKey()];
	for i = table.getn(lMatches), 1, -1 do table.remove(lMatches, i); end
	for i = 1, table.getn(lIndex) do
		local entry = lIndex[i];
		local starts = (string.sub(entry.lower, 1, length) == typed);
		if ((starts or string.find(entry.lower, " "..typed, 1, true)) and entry.lower ~= typed) then
			if (not entry.level) then
				-- nothing until the game has the item cached; asked again next time
				local _, _, quality, itemLevel = GetItemInfo(entry.id);
				entry.quality, entry.level = quality, itemLevel;
			end
			if (not entry.seen) then
				local _, _, count = string.find((data and data[entry.itemKey]) or "", "^(%d+)");
				entry.seen = tonumber(count) or 0;
			end
			local reagent = reagents[entry.name];
			entry.weight = (reagent and reagent.weight) or 0;
			entry.skill = reagent and reagent.skill;
			-- usable at this level (nearest first), no level, then too high
			if (entry.level and entry.level > 0) then
				if (entry.level <= level) then entry.tier = 0; else entry.tier = 2; end
				entry.distance = math.abs(level - entry.level);
			else
				entry.tier, entry.distance = 1, 0;
			end
			entry.starts = starts;
			table.insert(lMatches, entry);
		end
	end
	if (table.getn(lMatches) == 0) then
		hide();
		return;
	end
	table.sort(lMatches, sortMatches);
	show(box);
end

function show(box)
	if (not lFrame) then createFrame(); end
	lBox = box;
	local rows = math.min(table.getn(lMatches), MAX_ROWS);
	local level = UnitLevel("player");
	for i = 1, MAX_ROWS do
		local row = getglobal("AuctioneerSuggestFrameRow"..i);
		local entry = lMatches[i];
		if (i <= rows) then
			row.nameText:SetText(entry.name);
			local color = entry.quality and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[entry.quality];
			if (color) then
				row.nameText:SetTextColor(color.r, color.g, color.b);
			else
				row.nameText:SetTextColor(1, 1, 1);
			end
			if (entry.skill) then
				local c = WEIGHT_COLORS[entry.weight];
				row.tagText:SetText(entry.skill);
				row.tagText:SetTextColor(c[1], c[2], c[3]);
			elseif (entry.level and entry.level > 0) then
				row.tagText:SetText("Level "..entry.level);
				if (entry.level > level) then
					row.tagText:SetTextColor(1, 0.1, 0.1);
				else
					row.tagText:SetTextColor(0.6, 0.6, 0.6);
				end
			else
				row.tagText:SetText("");
			end
			row:Show();
		else
			row:Hide();
		end
	end
	lFrame:SetHeight(rows * ROW_HEIGHT + 12);
	lFrame:ClearAllPoints();
	lFrame:SetPoint("TOPLEFT", box, "BOTTOMLEFT", -8, 2);
	lFrame.hideAt = nil;
	lFrame:Show();
end

-- puts the chosen name in the box; a click also runs the box's own search, as Enter would
function accept(i, search)
	local box, entry = lBox, lMatches[i];
	hide();
	if (not box or not entry) then return; end
	lFilling = true;
	box:SetText(entry.name);
	lFilling = nil;
	-- a picked name is searched as exactly that item (see isPicked)
	box.auctioneerPicked = entry.name;
	if (search) then
		local enter = box:GetScript("OnEnterPressed");
		if (enter) then
			local saved = this;
			this = box;
			enter();
			this = saved;
		end
	end
end

function hide()
	if (lFrame) then
		lFrame:Hide();
		lFrame.hideAt = nil;
	end
	lBox = nil;
end

function hideSoon()
	if (lFrame and lFrame:IsShown()) then lFrame.hideAt = GetTime() + HIDE_DELAY; end
end

-- The list, drawn like a tooltip under the box. A child of the AH window, so it closes with it.
function createFrame()
	lFrame = CreateFrame("Frame", "AuctioneerSuggestFrame", AuctionFrame);
	lFrame:SetFrameStrata("DIALOG");
	lFrame:SetWidth(270);
	lFrame:SetBackdrop({
		bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
		edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
		tile = true, tileSize = 16, edgeSize = 16,
		insets = { left = 4, right = 4, top = 4, bottom = 4 },
	});
	lFrame:SetBackdropColor(0, 0, 0, 0.95);
	lFrame:EnableMouse(true);
	lFrame:Hide();
	lFrame:SetScript("OnUpdate", function()
		if (this.hideAt and GetTime() >= this.hideAt) then hide(); end
	end);
	for i = 1, MAX_ROWS do
		local row = CreateFrame("Button", "AuctioneerSuggestFrameRow"..i, lFrame);
		row:SetID(i);
		row:SetHeight(ROW_HEIGHT);
		row:SetPoint("TOPLEFT", lFrame, "TOPLEFT", 6, -6 - (i - 1) * ROW_HEIGHT);
		row:SetPoint("TOPRIGHT", lFrame, "TOPRIGHT", -6, -6 - (i - 1) * ROW_HEIGHT);
		local highlight = row:CreateTexture(nil, "HIGHLIGHT");
		highlight:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight");
		highlight:SetAllPoints(row);
		highlight:SetBlendMode("ADD");
		row.tagText = row:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall");
		row.tagText:SetPoint("RIGHT", row, "RIGHT", -2, 0);
		row.nameText = row:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall");
		row.nameText:SetHeight(ROW_HEIGHT);
		row.nameText:SetPoint("LEFT", row, "LEFT", 2, 0);
		row.nameText:SetPoint("RIGHT", row.tagText, "LEFT", -6, 0);
		row.nameText:SetJustifyH("LEFT");
		row:SetScript("OnClick", function() accept(this:GetID(), true); end);
	end
end

-- Adds the list to an edit box, keeping the box's own scripts: they run first, as before.
function attach(box)
	if (not box or box.auctioneerSuggest) then return; end
	box.auctioneerSuggest = true;
	local onTextChanged = box:GetScript("OnTextChanged");
	local onTabPressed = box:GetScript("OnTabPressed");
	local onEnterPressed = box:GetScript("OnEnterPressed");
	local onFocusGained = box:GetScript("OnEditFocusGained");
	local onFocusLost = box:GetScript("OnEditFocusLost");
	box:SetScript("OnTextChanged", function()
		if (onTextChanged) then onTextChanged(); end
		if (this.auctioneerFocus and not lFilling) then update(this); end
	end);
	box:SetScript("OnEditFocusGained", function()
		this.auctioneerFocus = true;
		if (onFocusGained) then onFocusGained(); end
	end);
	box:SetScript("OnEditFocusLost", function()
		this.auctioneerFocus = nil;
		if (onFocusLost) then onFocusLost(); end
		if (lBox == this) then hideSoon(); end
	end);
	-- Tab fills in the top name while the list is open; otherwise it does what it did
	box:SetScript("OnTabPressed", function()
		if (lBox == this and lMatches[1] and lFrame and lFrame:IsShown()) then
			accept(1);
		elseif (onTabPressed) then
			onTabPressed();
		end
	end);
	box:SetScript("OnEnterPressed", function()
		hide();
		-- on Browse, a picked name lists only that item, as after a Post Auctions search
		if (this == BrowseName and isPicked(this)) then
			Auctioneer.Scanning.SetBrowseOnlyName(this:GetText());
		end
		if (onEnterPressed) then onEnterPressed(); end
	end);
end

-- Whether the box still holds the name last picked from the list: then a search is for exactly
-- that item ("Iron Bar", not "Dark Iron Bar" too).
function isPicked(box)
	return (box.auctioneerPicked ~= nil and box:GetText() == box.auctioneerPicked);
end

Auctioneer.Suggest = {
	Attach = attach,
	Update = update,
	Accept = accept,
	Hide = hide,
	Reset = reset,
	GetMatches = function() return lMatches; end,
	IsPicked = isPicked,
}
