--[[
	Auctioneer Addon for World of Warcraft(tm).
	Version: 3.6.1 (Platypus)
	Revision: $Id: AHScanning.lua 675 2006-01-05 19:33:38Z mentalpower $

	AHScanning
	Functions for scanning the AH
	Thanks to Telo for the LootLink code from which this was based.

	License:
		This program is free software; you can redistribute it and/or
		modify it under the terms of the GNU General Public License
		as published by the Free Software Foundation; either version 2
		of the License, or (at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program(see GPL.txt); if not, write to the Free Software
		Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
]]

--Local function Prototypes
local nextIndex, stopAuctionScan, auctionSubmitQuery, auctionNextQuery, checkCompleteScan, scanAuction, canSendAuctionQuery, startAuctionScan, canScan, requestAuctionScan;
local scanClassesKey, saveResumePoint, clearResumePoint, getResumePoint, canResume, getResumeInfo;
local trace, reportUnknownCategory, isClassSelected, copySet, savedCategorySets, getFinishedCategories;
local unitKey, subclassFilter, subclassCount, isSubclassTicked, isClassPartial, isUnitSelected, findNextUnit, unitLabel;
local isSubclassChecked, findSubclass, tickWholeClass, setSubclassTicked;
local requestItemScan, getItemScanName, itemScanButtonUpdate, fullScanLabel;
local driveScan, getScanStatus, stopScanBy, unitProgress, currentScanLabel, browseSearchButtonUpdateWhileScanning, searchStopsScan, runPendingUserSearch;
local installScanHooks;

-- local variables
local isScanningRequested = false;
local lCurrentAuctionPage;
local lMajorAuctionCategories;
local lCurrentCategoryIndex;
local lCurrentSubclass;
local lIsPageScanned;
local lScanInProgress;
local lFullScan;
local lScanStartedAt;
local lPageStartedAt;
local lResumeRequested;
-- Item Scan/Search (Auctioneer-OctoWoW): the name asked for, the name the current or last scan
-- searched for (nil for a normal scan), and a name whose results still need showing.
local lItemScanRequest;
local lItemScanName;
-- an Item Scan started by the Post Auctions tab: it doesn't search the Browse tab afterwards
local lItemScanRequestQuiet;
local lItemScanQuiet;
local lItemSearchPending;
-- For the side scan panel (Auctioneer-OctoWoW): pages of the unit being scanned, pages scanned so
-- far, how the last scan ended ("finished", "stopped", "search") and what it was, why the scan is
-- being stopped right now, and a Browse search waiting to run after stopping a scan for it.
local lStatusPages;
local lPagesDone = 0;
local lLastOutcome;
local lLastLabel;
local lStopReason;
local lPendingUserSearch;
-- The categories this scan covers (a set of category numbers) and the units it has finished
-- (a set of unit keys, see unitKey), so a resumed scan can follow changes to which categories
-- are ticked. (Auctioneer-OctoWoW)
local lScanCategories = {};
local lDoneCategories = {};

-- A saved resume point older than this is ignored; most of those auctions are gone by then.
local RESUME_MAX_AGE = 12 * 60 * 60;

-- The last few scan steps, printed if a scan ever reaches a category that doesn't exist.
local lTrace = {};

-- function hooks
local lOriginal_CanSendAuctionQuery;
local lOriginal_AuctionFrameBrowse_OnEvent;
local lOriginal_AuctionFrameBrowse_Update;
local lOriginal_BrowseSearchButton_OnUpdate;
local lOriginal_AuctionFrameBrowse_Search;

-- TODO: If all categories are selected, then we should do a complete scan rather than a one-by-one scan.

-- Scan units (Auctioneer-OctoWoW): a ticked category is scanned whole while all its
-- subcategories are ticked, otherwise one ticked subcategory at a time. A unit's key is the
-- category number, or "category:subcategory" for a single subcategory.
function unitKey(c, s)
	if (s) then return c..":"..s; end
	return c;
end

function subclassFilter(c, s)
	return "scan-class"..c.."-"..s;
end

function subclassCount(c)
	return table.getn({GetAuctionItemSubClasses(c)});
end

-- subcategories count as ticked unless unticked, so a category starts out whole
function isSubclassTicked(c, s)
	return Auctioneer.Command.GetFilterVal(subclassFilter(c, s)) ~= "off";
end

function isClassPartial(c)
	for s = 1, subclassCount(c) do
		if (not isSubclassTicked(c, s)) then return true; end
	end
	return false;
end

-- whether a unit is still part of what's ticked
function isUnitSelected(c, s)
	if (not isClassSelected(c)) then return false; end
	if (s) then return isClassPartial(c) and isSubclassTicked(c, s); end
	return not isClassPartial(c);
end

-- the lowest ticked unit that isn't in done and isn't currentKey: category, subcategory or nil
function findNextUnit(done, currentKey)
	local categories = lMajorAuctionCategories or {GetAuctionItemClasses()};
	for c = 1, table.getn(categories) do
		if (isClassSelected(c)) then
			if (isClassPartial(c)) then
				for s = 1, subclassCount(c) do
					local key = unitKey(c, s);
					if (key ~= currentKey and not done[key] and isSubclassTicked(c, s)) then
						return c, s;
					end
				end
			elseif (c ~= currentKey and not done[c]) then
				return c, nil;
			end
		end
	end
	return nil;
end

-- get the next category index to based on what categories have been configured to be scanned:
-- the lowest ticked unit this scan hasn't finished yet, so categories ticked or unticked
-- during a scan are followed. Returns the category and the subcategory or nil. (Auctioneer-OctoWoW)
function nextIndex() --Local
	if (lCurrentCategoryIndex == nil) then lCurrentCategoryIndex = 0 end
	if (lFullScan) then return nil; end
	return findNextUnit(lDoneCategories, unitKey(lCurrentCategoryIndex, lCurrentSubclass));
end

function isClassSelected(i)
	return tostring(Auctioneer.Command.GetFilterVal("scan-class"..i)) == "on";
end

function copySet(set)
	local copy = {};
	for k, v in pairs(set or {}) do copy[k] = v; end
	return copy;
end

-- what a unit is called in the status text, e.g. "Weapon - Two-Handed Swords"
function unitLabel(c, s)
	local categories = lMajorAuctionCategories or {GetAuctionItemClasses()};
	local label = categories[c];
	if (label and s) then
		local subclasses = {GetAuctionItemSubClasses(c)};
		if (subclasses[s]) then label = label.." - "..subclasses[s]; end
	end
	return label;
end

-- the categories this scan has finished: [category] = true for a whole one, or the set of
-- subcategories finished in it; nil means everything (a whole-AH scan)
function getFinishedCategories()
	if (lFullScan) then return nil; end
	local finished = {};
	for key in pairs(lDoneCategories) do
		if (type(key) == "number") then
			finished[key] = true;
		else
			local _, _, c, s = string.find(key, "^(%d+):(%d+)$");
			c = tonumber(c);
			if (c and finished[c] ~= true) then
				if (not finished[c]) then finished[c] = {}; end
				finished[c][tonumber(s)] = true;
			end
		end
	end
	return finished;
end

-- Ticking subcategories in the AH category list (Auctioneer-OctoWoW)

function isSubclassChecked(c, s)
	return isClassSelected(c) and isSubclassTicked(c, s);
end

function findSubclass(c, name)
	local subclasses = {GetAuctionItemSubClasses(c)};
	for s = 1, table.getn(subclasses) do
		if (subclasses[s] == name) then return s; end
	end
end

-- ticking a category's own checkbox means the whole category again
function tickWholeClass(c)
	for s = 1, subclassCount(c) do
		Auctioneer.Command.SetFilter(subclassFilter(c, s), nil);
	end
end

function setSubclassTicked(c, s, ticked)
	if (ticked and not isClassSelected(c)) then
		-- ticking a subcategory of an unticked category scans just that subcategory
		Auctioneer.Command.SetFilter("scan-class"..c, "on");
		for i = 1, subclassCount(c) do
			if (i == s) then
				Auctioneer.Command.SetFilter(subclassFilter(c, i), nil);
			else
				Auctioneer.Command.SetFilter(subclassFilter(c, i), "off");
			end
		end
		return;
	end
	if (ticked) then
		Auctioneer.Command.SetFilter(subclassFilter(c, s), nil);
		return;
	end
	Auctioneer.Command.SetFilter(subclassFilter(c, s), "off");
	-- unticking the last one unticks the category, which is whole again when ticked
	for i = 1, subclassCount(c) do
		if (isSubclassTicked(c, i)) then return; end
	end
	Auctioneer.Command.SetFilter("scan-class"..c, "off");
	tickWholeClass(c);
end

-- Resume points (Auctioneer-OctoWoW): the scan position is saved in AuctionConfig after
-- every page, so a scan cut short by closing the AH, logging out or an AFK disconnect
-- can carry on from there with the Resume Scan button instead of starting over at page 1.

-- which categories the scan covers, one character each: 1 = whole, p = some subcategories,
-- 0 = not ticked. All 1s is a whole-AH scan.
function scanClassesKey()
	local categories = lMajorAuctionCategories or {GetAuctionItemClasses()};
	local key = "";
	for i = 1, table.getn(categories) do
		if (not isClassSelected(i)) then
			key = key.."0";
		elseif (isClassPartial(i)) then
			key = key.."p";
		else
			key = key.."1";
		end
	end
	return key;
end

function saveResumePoint()
	-- an Item Scan/Search leaves the resume point of a normal scan alone
	if (not lScanInProgress or lItemScanName) then return; end
	if (not AuctionConfig.scanResume) then AuctionConfig.scanResume = {}; end
	AuctionConfig.scanResume[Auctioneer.Util.GetAuctionKey()] = {
		classes = scanClassesKey(),
		full = lFullScan,
		category = lCurrentCategoryIndex,
		subclass = lCurrentSubclass,
		page = lCurrentAuctionPage,
		scanned = copySet(lScanCategories),
		done = copySet(lDoneCategories),
		savedAt = time(),
	};
end

function clearResumePoint()
	if (AuctionConfig.scanResume) then
		AuctionConfig.scanResume[Auctioneer.Util.GetAuctionKey()] = nil;
	end
end

-- the categories a saved scan covered and finished; points saved before these were kept
-- are worked out from its ticked categories, which were scanned in numerical order
function savedCategorySets(resume)
	if (resume.scanned and resume.done) then
		return copySet(resume.scanned), copySet(resume.done);
	end
	local scanned, done = {}, {};
	for i = 1, string.len(resume.classes or "") do
		if (string.sub(resume.classes, i, i) == "1") then
			scanned[i] = true;
			if (i < resume.category) then done[i] = true; end
		end
	end
	return scanned, done;
end

-- Where Resume Scan would carry on with the categories ticked right now:
-- { category = , subclass = , page = , full = , saved = } or nil when there's nothing to resume
function getResumePoint()
	if (not AuctionConfig.scanResume) then return nil; end
	local resume = AuctionConfig.scanResume[Auctioneer.Util.GetAuctionKey()];
	if (not resume or time() - resume.savedAt > RESUME_MAX_AGE) then return nil; end
	local categories = lMajorAuctionCategories or {GetAuctionItemClasses()};
	if (type(resume.category) ~= "number" or not categories[resume.category]) then
		return nil;
	end

	local full = resume.full;
	if (full == nil) then full = not string.find(resume.classes or "0", "[0p]"); end
	if (full) then
		-- whole-AH pages don't map onto single categories, so this only resumes unchanged
		if (resume.classes ~= scanClassesKey()) then return nil; end
		return { category = resume.category, page = resume.page, full = true, saved = resume };
	end

	-- carry on in the category we were in, from the page we were on, while it's still ticked
	if (isUnitSelected(resume.category, resume.subclass)) then
		return { category = resume.category, subclass = resume.subclass, page = resume.page, saved = resume };
	end
	-- it was unticked: go on with the lowest ticked one not finished yet
	local _, done = savedCategorySets(resume);
	local c, s = findNextUnit(done, unitKey(resume.category, resume.subclass));
	if (c) then
		return { category = c, subclass = s, page = 0, saved = resume };
	end
	return nil;
end

function canResume()
	return canScan() and getResumePoint() ~= nil;
end

-- what Resume Scan would continue: category name (nil for the whole AH) and 1-based page
function getResumeInfo()
	local resume = getResumePoint();
	if (not resume) then return nil; end
	if (resume.full) then return nil, resume.page + 1; end
	return unitLabel(resume.category, resume.subclass), resume.page + 1;
end

function trace(step)
	table.insert(lTrace, string.format("%s %s (category %s, page %s)", date("%H:%M:%S"), step, tostring(unitKey(lCurrentCategoryIndex or 0, lCurrentSubclass)), tostring(lCurrentAuctionPage)));
	if (table.getn(lTrace) > 12) then table.remove(lTrace, 1); end
end

-- A category scan has reached a category with no name, which used to stop the addon with
-- "bad argument #2 to format". Stop the scan cleanly instead and print how it got there.
-- The saved position stays, so Resume Scan carries on. (Auctioneer-OctoWoW)
function reportUnknownCategory()
	Auctioneer.Util.ChatPrint(string.format("Auctioneer-OctoWoW: scan stopped at unknown category %s (%s, %d categories) on page %s. Resume Scan continues it. Please report these lines:",
		tostring(lCurrentCategoryIndex), type(lCurrentCategoryIndex), table.getn(lMajorAuctionCategories or {}), tostring(lCurrentAuctionPage)));
	for _, step in ipairs(lTrace) do
		Auctioneer.Util.ChatPrint("  "..step);
	end
	for line in string.gfind(debugstack(2, 6, 0) or "", "[^\n]+") do
		Auctioneer.Util.ChatPrint("  "..line);
	end
	stopAuctionScan();
end

function stopAuctionScan()
	trace("stop");
	-- what the side scan panel shows afterwards (Auctioneer-OctoWoW)
	if (lScanInProgress) then
		lLastOutcome = lStopReason or "stopped";
		lLastLabel = currentScanLabel();
	end
	lStopReason = nil;
	Auctioneer.Event.StopAuctionScan();

	-- Unhook the scanning functions
	if( lOriginal_CanSendAuctionQuery ) then
		CanSendAuctionQuery = lOriginal_CanSendAuctionQuery;
		lOriginal_CanSendAuctionQuery = nil;
	end

	if( lOriginal_AuctionFrameBrowse_OnEvent ) then
		AuctionFrameBrowse_OnEvent = lOriginal_AuctionFrameBrowse_OnEvent;
		lOriginal_AuctionFrameBrowse_OnEvent = nil;
	end

	if( lOriginal_AuctionFrameBrowse_Update ) then
		AuctionFrameBrowse_Update = lOriginal_AuctionFrameBrowse_Update;
		lOriginal_AuctionFrameBrowse_Update = nil;
	end

	if( lOriginal_BrowseSearchButton_OnUpdate ) then
		BrowseSearchButton_OnUpdate = lOriginal_BrowseSearchButton_OnUpdate;
		lOriginal_BrowseSearchButton_OnUpdate = nil;
	end

	if( lOriginal_AuctionFrameBrowse_Search ) then
		AuctionFrameBrowse_Search = lOriginal_AuctionFrameBrowse_Search;
		lOriginal_AuctionFrameBrowse_Search = nil;
	end

	Auctioneer.Scanning.IsScanningRequested = false;
	lScanInProgress = false;
	lCurrentCategoryIndex = 0;
	lCurrentSubclass = nil;
	lPageStartedAt = nil;

	-- Unprotect AuctionFrame if we should
	if (Auctioneer.Command.GetFilterVal('protect-window') == 1) then
		Auctioneer.Util.ProtectAuctionFrame(false);
	end
end

function auctionSubmitQuery() --Local
	if not lCurrentAuctionPage or lCurrentAuctionPage == 0 then
		if not lCurrentAuctionPage then lCurrentAuctionPage = 0 end
		if lFullScan then
			BrowseNoResultsText:SetText(string.format(_AUCT('AuctionScanStart'), fullScanLabel()));
		elseif (not lMajorAuctionCategories[lCurrentCategoryIndex]) then
			reportUnknownCategory();
			return;
		else
			BrowseNoResultsText:SetText(string.format(_AUCT('AuctionScanStart'), unitLabel(lCurrentCategoryIndex, lCurrentSubclass)));
		end
	end
	if (lFullScan) then
		QueryAuctionItems(lItemScanName or "", "", "", nil, nil, nil, lCurrentAuctionPage, nil, nil);
	else
		QueryAuctionItems("", "", "", nil, lCurrentCategoryIndex, lCurrentSubclass, lCurrentAuctionPage, nil, nil);
	end
	lPageStartedAt = time();

	lIsPageScanned = false;
	Auctioneer.Event.AuctionQuery(lCurrentAuctionPage);
end

function auctionNextQuery() --Local
	lCheckPage = nil;
	if lCurrentAuctionPage then
		local numBatchAuctions, totalAuctions = GetNumAuctionItems("list");
		local maxPages = floor(totalAuctions / NUM_AUCTION_ITEMS_PER_PAGE);

		local auctionsPerSecond = ( Auctioneer.Core.Variables.TotalAuctionsScannedCount / ( GetTime() - lScanStartedAt ) );
		local auctionETA = ( ( totalAuctions - Auctioneer.Core.Variables.TotalAuctionsScannedCount ) / auctionsPerSecond );
		auctionsPerSecond = floor( auctionsPerSecond * 100 ) / 100;
		if ( type(auctionsPerSecond) ~= "number" ) then
			auctionsPerSecond = "";
		else
			auctionsPerSecond = tostring(auctionsPerSecond);
		end
		local ETAString = SecondsToTime(auctionETA);

		if( lCurrentAuctionPage < maxPages ) then
			lPageStartedAt = time();
			lCurrentAuctionPage = lCurrentAuctionPage + 1;
			if lFullScan then
				BrowseNoResultsText:SetText(string.format(_AUCT('AuctionPageN'), fullScanLabel(), lCurrentAuctionPage + 1, maxPages + 1, auctionsPerSecond, ETAString));
			elseif (not lMajorAuctionCategories[lCurrentCategoryIndex]) then
				reportUnknownCategory();
				return;
			else
				BrowseNoResultsText:SetText(string.format(_AUCT('AuctionPageN'), unitLabel(lCurrentCategoryIndex, lCurrentSubclass), lCurrentAuctionPage + 1, maxPages + 1, auctionsPerSecond, ETAString));
			end
		elseif nextIndex() then
			lPageStartedAt = time();
			lDoneCategories[unitKey(lCurrentCategoryIndex, lCurrentSubclass)] = true;
			lCurrentCategoryIndex, lCurrentSubclass = nextIndex();
			lCurrentAuctionPage = 0;
			lStatusPages = nil;
			trace("next category");
		else
			lDoneCategories[unitKey(lCurrentCategoryIndex, lCurrentSubclass)] = true;
			trace("finished");
			local itemScan = lItemScanName;
			if (not itemScan) then clearResumePoint(); end
			lStopReason = "finished";
			stopAuctionScan();
			-- an Item Scan/Search also finishes with no auctions found, so gone ones are cleaned up
			if( totalAuctions > 0 or itemScan ) then
				BrowseNoResultsText:SetText(_AUCT('AuctionScanDone'));
				Auctioneer.Event.FinishedAuctionScan();
			end
			-- then shows what it found, like a normal search (see itemScanButtonUpdate), unless the
			-- Post Auctions tab started it; that tab refreshes its suggested prices instead
			if (itemScan and not lItemScanQuiet) then lItemSearchPending = itemScan; end
			if (itemScan and AuctionFramePost and AuctionFramePost.RefreshAfterItemScan) then
				AuctionFramePost:RefreshAfterItemScan(itemScan);
			end
			return;
		end
	end
	auctionSubmitQuery();
end

local lCheckStartTime = nil;
local lCheckPage = nil;
local lCheckSize = nil;
local lCheckPos = nil;
function checkCompleteScan()
	if (lCheckPage ~= lCurrentAuctionPage) or (not lCheckSize) or (not lCheckPos) then
		lCheckSize = GetNumAuctionItems("list");
		lCheckPage = lCurrentAuctionPage;
		lCheckPos = 1;
		lCheckStartTime = time()
	end

	if lCheckPage and lCheckSize > 0 then
		if (time() - lCheckStartTime > 10) then
			-- Sometimes they never return an owner.
			return true
		end
		for auctionid = lCheckPos, lCheckSize do
			lCheckPos = auctionid;
			local _,_,_,_,_,_,_,_,_,_,_, owner = GetAuctionItemInfo("list", auctionid);
			if (owner == nil) then return false end
		end
	end
	return true;
end

function scanAuction()
	local numBatchAuctions, totalAuctions = GetNumAuctionItems("list");
	local auctionid;

	if( numBatchAuctions > 0 ) then
		for auctionid = 1, numBatchAuctions do
			Auctioneer.Event.ScanAuction(lCurrentAuctionPage, auctionid, lCurrentCategoryIndex);
		end
	end

	-- for the side scan panel (Auctioneer-OctoWoW)
	lPagesDone = lPagesDone + 1;
	lStatusPages = math.max(1, math.ceil(totalAuctions / NUM_AUCTION_ITEMS_PER_PAGE));

	lIsPageScanned = true;
	saveResumePoint();
end

function canSendAuctionQuery() --Local
	local value = lOriginal_CanSendAuctionQuery();
	if (value and lIsPageScanned) then
		auctionNextQuery();
		return nil;
	end
	if (lPageStartedAt) then
		local pageElapsed = time() - lPageStartedAt;
		if (pageElapsed > 20) then
			trace("page retry");
			if (Auctioneer.Command.GetFilter('show-warning')) then
				Auctioneer.Util.ChatPrint(string.format(_AUCT('AuctionScanRedo'), 20));
			end
			auctionSubmitQuery();
			return nil;
		end
		return false;
	end
end
Auctioneer.AuctionFrameBrowse = {
	OnEvent = function()
		-- Intentionally empty; don't allow the auction UI to update while we're scanning
	end,
	Update = function()
		-- Intentionally empty; don't allow the auction UI to update while we're scanning
	end,
	-- During an Item Scan/Search the list shows each page as it's scanned, but read-only: Bid and
	-- Buyout stay off until it's done, since the list keeps changing under them. (Auctioneer-OctoWoW)
	ItemScanUpdate = function()
		if (lOriginal_AuctionFrameBrowse_Update) then lOriginal_AuctionFrameBrowse_Update(); end
		BrowseBidButton:Disable();
		BrowseBuyoutButton:Disable();
		local _, total = GetNumAuctionItems("list");
		BrowseSearchCountText:SetText(string.format("Item Scan: page %d of %d", (lCurrentAuctionPage or 0) + 1, math.max(1, math.ceil((total or 0) / NUM_AUCTION_ITEMS_PER_PAGE))));
		BrowseSearchCountText:Show();
	end
};




-- Hooks the functions the scan needs and resets what the side scan panel shows. Kept out of
-- startAuctionScan, which would otherwise use more than the 32 outer locals ("upvalues") a
-- function may use in WoW's Lua 5.0. (Auctioneer-OctoWoW)
function installScanHooks()
	-- Hook the functions that we need for the scan
	if( not lOriginal_CanSendAuctionQuery ) then
		lOriginal_CanSendAuctionQuery = CanSendAuctionQuery;
		CanSendAuctionQuery = canSendAuctionQuery;
	end

	-- An Item Scan/Search keeps the Browse list updating, read-only (see ItemScanUpdate)
	if( not lOriginal_AuctionFrameBrowse_OnEvent ) then
		lOriginal_AuctionFrameBrowse_OnEvent = AuctionFrameBrowse_OnEvent;
		if (lItemScanName) then
			AuctionFrameBrowse_OnEvent = lOriginal_AuctionFrameBrowse_OnEvent;
		else
			AuctionFrameBrowse_OnEvent = Auctioneer.AuctionFrameBrowse.OnEvent;
		end
	end

	if( not lOriginal_AuctionFrameBrowse_Update ) then
		lOriginal_AuctionFrameBrowse_Update = AuctionFrameBrowse_Update;
		if (lItemScanName) then
			AuctionFrameBrowse_Update = Auctioneer.AuctionFrameBrowse.ItemScanUpdate;
		else
			AuctionFrameBrowse_Update = Auctioneer.AuctionFrameBrowse.Update;
		end
	end

	-- The side scan panel drives the scan now (driveScan), so the Browse tab's Search button
	-- stays clickable during a scan, and a search stops the scan first.
	if( not lOriginal_BrowseSearchButton_OnUpdate ) then
		lOriginal_BrowseSearchButton_OnUpdate = BrowseSearchButton_OnUpdate;
		BrowseSearchButton_OnUpdate = browseSearchButtonUpdateWhileScanning;
	end

	if( not lOriginal_AuctionFrameBrowse_Search ) then
		lOriginal_AuctionFrameBrowse_Search = AuctionFrameBrowse_Search;
		AuctionFrameBrowse_Search = searchStopsScan;
	end

	lStatusPages = nil;
	lPagesDone = 0;
	lLastOutcome = nil;
	lPendingUserSearch = nil;
end

function startAuctionScan()
	-- Starting again mid-scan (a typed /auctioneer scan, the AH being shown again) used to move
	-- the running category scan on by one, and past the last category to category 0, which
	-- broke the status text with "bad argument #2 to format". (Auctioneer-OctoWoW)
	if (lScanInProgress) then
		trace("start ignored, scan running");
		return;
	end

	lMajorAuctionCategories = {GetAuctionItemClasses()};

	-- An Item Scan/Search goes through the pages of one name search, like a whole-AH scan.
	lItemScanName = lItemScanRequest;
	lItemScanQuiet = lItemScanRequestQuiet;
	lItemScanRequest = nil;
	lItemScanRequestQuiet = nil;
	if (lItemScanName) then
		lFullScan = true;
	else
		-- a whole-AH scan when every category is ticked with all its subcategories
		lFullScan = not string.find(scanClassesKey(), "[0p]");
	end

	lDoneCategories = {};
	if (lFullScan) then
		lCurrentCategoryIndex = table.getn(lMajorAuctionCategories);
		lCurrentSubclass = nil;
	else
		-- first make sure that we have at least one category to scan
		lCurrentCategoryIndex = 0;
		lCurrentSubclass = nil;
		lCurrentCategoryIndex, lCurrentSubclass = nextIndex();
		if not lCurrentCategoryIndex then
			lCurrentCategoryIndex = 0;
			trace("start, no category selected");
			Auctioneer.Util.ChatPrint(_AUCT('AuctionScanNocat'));
			-- nothing to scan, so the request ends here; it used to stay open, leaving Stop lit and
			-- list updates from normal searches fed to the scanner (Auctioneer-OctoWoW)
			Auctioneer.Scanning.IsScanningRequested = false;
			lResumeRequested = nil;
			return;
		end
	end

	-- Start with the first page, or where an unfinished scan left off
	lCurrentAuctionPage = nil;
	local resume = nil;
	if (lResumeRequested and not lItemScanName) then
		resume = getResumePoint();
	end
	lResumeRequested = nil;
	local newCategories = nil;
	if (resume) then
		-- Carry on with the resumed scan's categories. Ones ticked since it started join it,
		-- and get their "possibly gone" marks from the start event below.
		lFullScan = resume.full or false;
		lScanCategories, lDoneCategories = savedCategorySets(resume.saved);
		if (not lFullScan) then
			for i = 1, table.getn(lMajorAuctionCategories) do
				if (isClassSelected(i) and not lScanCategories[i]) then
					if (not newCategories) then newCategories = {}; end
					newCategories[i] = true;
					lScanCategories[i] = true;
				end
			end
		end
	else
		-- a fresh scan replaces any unfinished one, but an Item Scan/Search leaves it be
		if (not lItemScanName) then clearResumePoint(); end
		lScanCategories = {};
		for i = 1, table.getn(lMajorAuctionCategories) do
			if (lFullScan or isClassSelected(i)) then lScanCategories[i] = true; end
		end
	end
	lScanInProgress = true;
	installScanHooks();

	Auctioneer.Event.StartAuctionScan(resume ~= nil, newCategories, lItemScanName);
	-- Something run by the start event (the AH closing, say) may already have stopped the scan.
	if (not lScanInProgress) then
		trace("stopped while starting");
		return;
	end
	if (resume) then trace("start, resume"); elseif (lItemScanName) then trace("start, item scan"); elseif (lFullScan) then trace("start, full"); else trace("start, categories"); end

	lScanStartedAt = GetTime();
	if (resume) then
		-- Re-read the last saved page too, in case auctions shifted while we were away.
		lCurrentCategoryIndex = resume.category;
		lCurrentSubclass = resume.subclass;
		lCurrentAuctionPage = resume.page;
		local where = string.format("page %d", resume.page + 1);
		if (not lFullScan) then where = unitLabel(resume.category, resume.subclass)..", "..where; end
		Auctioneer.Util.ChatPrint("Auctioneer: resuming the unfinished scan: "..where..".");
		BrowseNoResultsText:SetText("Resuming scan: "..where.."...");
		auctionSubmitQuery();
	else
		auctionNextQuery();
	end
end

function canScan()
	if (lScanInProgress) then
		return false;
	end
	if (not CanSendAuctionQuery()) then
		return false;
	end
	if (AucBidManager.IsProcessingRequest()) then
		return false;
	end
	return true;
end

function requestAuctionScan(resume, itemName, quiet)
	lResumeRequested = resume;
	lItemScanRequest = itemName;
	lItemScanRequestQuiet = quiet;
	Auctioneer.Scanning.IsScanningRequested = true;
	if (AuctionFrame and AuctionFrame:IsVisible()) then
		local iButton;
		local button;

		-- Hide the UI from any current results, show the no results text so we can use it
		BrowseNoResultsText:Show();
		for iButton = 1, NUM_BROWSE_TO_DISPLAY do
			button = getglobal("BrowseButton"..iButton);
			button:Hide();
		end
		BrowsePrevPageButton:Hide();
		BrowseNextPageButton:Hide();
		BrowseSearchCountText:Hide();

		-- a buyout confirmation left open would act on whatever the list holds by then
		StaticPopup_Hide("BUYOUT_AUCTION");

		startAuctionScan();
	else
		Auctioneer.Util.ChatPrint(_AUCT('AuctionScanNexttime'));
	end
end

-- Item Scan/Search (Auctioneer-OctoWoW): scans every page of the AH's name search for an item,
-- like Blizzard's Name box (so "Linen" also finds "Bolt of Linen Cloth"), then shows the
-- results like a normal search. It doesn't touch a normal scan's resume point, and only
-- auctions whose name matches are marked "possibly gone" and cleaned up.

-- what the status text calls a scan that isn't by category
function fullScanLabel()
	if (lItemScanName) then return "\""..lItemScanName.."\""; end
	return _AUCT('TextAuction');
end

-- the name the current or last scan searched for, nil for a normal scan
function getItemScanName()
	return lItemScanName;
end

-- quiet: started by the Post Auctions tab, so the Browse tab isn't searched afterwards
function requestItemScan(name, quiet)
	name = string.gsub(name or "", "^%s*(.-)%s*$", "%1");
	if (name == "") then
		Auctioneer.Util.ChatPrint("Auctioneer: type an item name in the Item Scan/Search box first, or Shift+Right-click an item in your bags.");
		return;
	end
	requestAuctionScan(nil, name, quiet);
end

-- OnUpdate of the Item Scan button: enables it, and once an Item Scan/Search has finished and
-- the AH takes queries again, searches for that name so its auctions show in the list.
function itemScanButtonUpdate(button)
	if (canScan()) then
		button:Enable();
	else
		button:Disable();
	end
	if (lItemSearchPending and not lScanInProgress and AuctionFrameBrowse:IsVisible() and CanSendAuctionQuery()) then
		local name = lItemSearchPending;
		lItemSearchPending = nil;
		BrowseName:SetText(name);
		BrowseMinLevel:SetText("");
		BrowseMaxLevel:SetText("");
		AuctionFrameBrowse.selectedInvtype = nil;
		AuctionFrameBrowse.selectedInvtypeIndex = nil;
		AuctionFrameBrowse.selectedClass = nil;
		AuctionFrameBrowse.selectedClassIndex = nil;
		AuctionFrameBrowse.selectedSubclass = nil;
		AuctionFrameBrowse.selectedSubclassIndex = nil;
		AuctionFrameFilters_Update();
		IsUsableCheckButton:SetChecked(0);
		UIDropDownMenu_SetSelectedValue(BrowseDropDown, -1);
		AuctionFrameBrowse_Search();
	end
end

-- The side scan panel (Auctioneer-OctoWoW). Scans used to move only while the Browse tab's Search
-- button was there to poll CanSendAuctionQuery, so they stalled on every other tab. The panel
-- calls driveScan every frame instead, so the Bids, Auctions, Search Auctions and Post Auctions
-- tabs can be used while a scan runs. The Browse tab can't: the AH has one result list, which
-- the scan is reading, so a search there stops the scan first (Resume continues it).

function driveScan()
	if (lScanInProgress and lOriginal_CanSendAuctionQuery) then
		canSendAuctionQuery();
	end
	runPendingUserSearch();
end

-- Stops the scan, remembering why for the panel: "stopped" (the Stop button) or "search". A
-- scan that was asked for but never started (the AH was closed, or nothing could be scanned)
-- is cancelled too; Stop used to light up for those and then do nothing.
function stopScanBy(reason)
	if (not lScanInProgress) then
		if (Auctioneer.Scanning.IsScanningRequested) then
			Auctioneer.Scanning.IsScanningRequested = false;
			lLastLabel = lItemScanRequest and ("\"" .. lItemScanRequest .. "\"") or nil;
			lItemScanRequest, lItemScanRequestQuiet, lResumeRequested = nil, nil, nil;
			lLastOutcome = reason;
			trace("cancelled before starting");
		end
		return;
	end
	local itemScan = lItemScanName;
	lStopReason = reason;
	stopAuctionScan();
	-- say so on the Browse tab too, instead of leaving the last "Scanning ... page" line there
	if (reason == "stopped" and AuctionFrameBrowse and AuctionFrameBrowse:IsVisible()) then
		if (itemScan) then
			-- the item's last scanned page, now a normal, usable list again; the line only shows
			-- if that page was empty
			BrowseNoResultsText:SetText("Item Scan stopped.");
			AuctionFrameBrowse_Update();
		else
			BrowseNoResultsText:SetText("Scan stopped. Resume carries on where it stopped.");
			BrowseNoResultsText:Show();
		end
	end
	-- a Post Auctions item scan: its "Scanning the auction house..." note gives way to prices
	-- from the pages it got through
	if (itemScan and AuctionFramePost and AuctionFramePost.RefreshAfterItemScan) then
		AuctionFramePost:RefreshAfterItemScan(itemScan);
	end
end

-- BrowseSearchButton_OnUpdate while scanning: Search stays clickable, paging stays off
function browseSearchButtonUpdateWhileScanning()
	this:Enable();
	BrowsePrevPageButton:Disable();
	BrowseNextPageButton:Disable();
end

-- AuctionFrameBrowse_Search while scanning: stop the scan, then search once the AH takes queries
function searchStopsScan(page)
	lPendingUserSearch = { page = page };
	stopScanBy("search");
	runPendingUserSearch();
end

function runPendingUserSearch()
	if (lPendingUserSearch and not lScanInProgress and CanSendAuctionQuery()) then
		local page = lPendingUserSearch.page;
		lPendingUserSearch = nil;
		AuctionFrameBrowse_Search(page);
	end
end

-- what the running scan covers, e.g. "Whole auction house", "Weapon - Bows" or "\"Linen\""
function currentScanLabel()
	if (lItemScanName) then return "\""..lItemScanName.."\""; end
	if (lFullScan) then return "Whole auction house"; end
	if (lCurrentCategoryIndex and lMajorAuctionCategories and lMajorAuctionCategories[lCurrentCategoryIndex]) then
		return unitLabel(lCurrentCategoryIndex, lCurrentSubclass);
	end
end

-- which of the ticked categories (or subcategories) this is, and how many there are
function unitProgress()
	local done, total = 0, 0;
	for c = 1, table.getn(lMajorAuctionCategories) do
		if (isClassSelected(c)) then
			if (isClassPartial(c)) then
				for s = 1, subclassCount(c) do
					if (isSubclassTicked(c, s)) then
						total = total + 1;
						if (lDoneCategories[unitKey(c, s)]) then done = done + 1; end
					end
				end
			else
				total = total + 1;
				if (lDoneCategories[c]) then done = done + 1; end
			end
		end
	end
	-- the one being scanned still counts if it has been unticked meanwhile
	if (not isUnitSelected(lCurrentCategoryIndex, lCurrentSubclass)) then total = total + 1; end
	return math.min(done + 1, total), total;
end

-- everything the side scan panel shows
function getScanStatus()
	local status = {
		scanning = lScanInProgress,
		itemScan = lItemScanName,
		outcome = lLastOutcome,
		seen = Auctioneer.Core.Variables.TotalAuctionsScannedCount or 0,
		pagesDone = lPagesDone,
		canResume = canResume(),
	};
	if (lScanInProgress) then
		status.label = currentScanLabel();
		status.page = (lCurrentAuctionPage or 0) + 1;
		status.pages = lStatusPages;
		status.elapsed = lScanStartedAt and (GetTime() - lScanStartedAt);
		if (not lFullScan and lMajorAuctionCategories) then
			status.unit, status.units = unitProgress();
		end
	else
		status.label = lLastLabel;
	end
	return status;
end

Auctioneer.Scanning = {
	IsScanningRequested = isScanningRequested,
	DriveScan = driveScan,
	GetScanStatus = getScanStatus,
	StopScanBy = stopScanBy,
	RequestItemScan = requestItemScan,
	GetItemScanName = getItemScanName,
	ItemScanButtonUpdate = itemScanButtonUpdate,
	StopAuctionScan = stopAuctionScan,
	CheckCompleteScan = checkCompleteScan,
	ScanAuction = scanAuction,
	StartAuctionScan = startAuctionScan,
	CanScan = canScan,
	RequestAuctionScan = requestAuctionScan,
	CanResume = canResume,
	GetResumeInfo = getResumeInfo,
	GetFinishedCategories = getFinishedCategories,
	IsSubclassChecked = isSubclassChecked,
	FindSubclass = findSubclass,
	TickWholeClass = tickWholeClass,
	SetSubclassTicked = setSubclassTicked,
}