--[[
	Auctioneer
	Revision: $Id: Auctioneer.lua 844 2006-04-29 23:33:49Z aradan $
	Version: 3.6.1 (Platypus)
	Original version written by Norganna.
	Contributors: Araband

	This is an addon for World of Warcraft that adds statistical history to the auction data that is collected
	when the auction is scanned, so that you can easily determine what price
	you will be able to sell an item for at auction or at a vendor whenever you
	mouse-over an item in the game

	License:
		This program is free software; you can redistribute it and/or
		modify it under the terms of the GNU General Public License
		as published by the Free Software Foundation; either version 2
		of the License, or (at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program(see GPL.txt); if not, write to the Free Software
		Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
]]


Auctioneer.Version="3.6.1";
-- If you want to see debug messages, create a window called "Debug" within the client.
if (Auctioneer.Version == "<".."%version%>") then
	Auctioneer.Version = "3.5.DEV";
end

-- /auc-glossary explains the shorthand Auctioneer shows in chat, tooltips and the AH frames.
-- It's Stubby boot code like /auctioneer, so it also works before Auctioneer is loaded.
-- /auc-glossary <word> shows only the terms containing that word. (Auctioneer-OctoWoW)
local glossaryBootCode = [[
	local terms = {
		{ "AH", "Auction house." },
		{ "bb / bidbroker", "/auctioneer bb <silver>: auctions ending soon that you can win with a bid and resell for at least that much profit." },
		{ "BO", "Buyout: the price to buy an auction right away, without bidding." },
		{ "broker", "/auctioneer broker <silver>: auctions you can buy out and resell for at least that much profit." },
		{ "compete", "/auctioneer compete <silver>: other players' auctions that are at least that much cheaper per item than yours." },
		{ "curBid", "The current highest bid on an auction." },
		{ "ea / each / For 1", "The price for a single item of a stack." },
		{ "historical / Last N", "Prices from all your past scans (the last N auctions seen)." },
		{ "HSP", "Highest Sellable Price: Auctioneer's suggested buyout, the most you can ask while still being the cheapest. Normally it undercuts the cheapest auction by 5%, or goes 2% under market price when nobody else is selling. See the pct- settings." },
		{ "in N's", "The stack size the item is usually sold in, e.g. [in 20's]." },
		{ "Market price", "The median buyout from your scans, or the average buyout if there's no median yet." },
		{ "Median", "The middle price of everything seen, so a few silly listings don't pull it around." },
		{ "min / minBid", "The minimum bid, which is also an auction's starting price." },
		{ "No competition", "Nobody else was selling the item in your last scan." },
		{ "No data for HSP", "Not enough price data to suggest a price yet. Scan the item's category, or type a price yourself." },
		{ "pct-bidmarkdown", "Starting price is the suggested buyout minus this many percent. Default 20. Change it with /auctioneer pct-bidmarkdown <percent>, like the other pct- settings." },
		{ "pct-markup", "With no auction data at all, use the vendor price plus this many percent. Default 300. Needs the Informant addon." },
		{ "post-scan", "Putting an item in the Post Auctions slot first runs an Item Scan for it, so its suggested prices are up to date. On by default; /auctioneer post-scan off turns it off." },
		{ "pct-maxover", "On the Post Auctions tab, a competitor priced above market is undercut too, but never more than this many percent over market. Default 200 (up to 3x market)." },
		{ "pct-maxless", "If the cheapest auction is more than this many percent under market price, don't chase it. Default 30." },
		{ "pct-nocomp", "Go this many percent under market price when nobody else is selling. Default 2." },
		{ "pct-underlow", "Undercut the cheapest auction by this many percent. Default 5." },
		{ "pct-undermkt", "When the cheapest auction is too cheap to chase, go this many percent under market price instead. Default 20." },
		{ "pl / percentless", "/auctioneer pl <percent>: buyouts at least that many percent under HSP." },
		{ "Prof", "Profit: what you'd make by reselling at HSP, minus what you pay." },
		{ "Seen N times", "How many auctions of the item your scans have recorded." },
		{ "Snapshot / last scan", "What was on the auction house during your latest scan." },
		{ "Snapshot low", "The cheapest buyout for the item in your latest scan." },
		{ "Undercut", "Listing a little cheaper than the cheapest competitor, so yours sells first." },
	}
	local function glossary(msg)
		local word = string.lower(string.gsub(msg or "", "^%s*(.-)%s*$", "%1"))
		local shown = 0
		for i = 1, table.getn(terms) do
			local term, text = terms[i][1], terms[i][2]
			if (word == "" or string.find(string.lower(term), word, 1, true)) then
				if (shown == 0) then
					DEFAULT_CHAT_FRAME:AddMessage("Auctioneer glossary (/auc-glossary <word> looks one up):", 1, 0.82, 0)
				end
				DEFAULT_CHAT_FRAME:AddMessage("|cffffffff"..term.."|r - "..text, 1, 0.82, 0)
				shown = shown + 1
			end
		end
		if (shown == 0) then
			DEFAULT_CHAT_FRAME:AddMessage("Auctioneer glossary: nothing matches \""..word.."\". Type /auc-glossary to see every term.", 1, 0.82, 0)
		end
	end
	SLASH_AUCTGLOSSARY1 = "/auc-glossary"
	SlashCmdList["AUCTGLOSSARY"] = glossary
]];

local function onLoad()
	-- Unhook some boot triggers if necessary.
	-- These might not exist on initial loading or if an addon depends on Auctioneer
	if (Auctioneer_CheckLoad) then
		Stubby.UnregisterFunctionHook("AuctionFrame_LoadUI", Auctioneer_CheckLoad);
	end
	if (Auctioneer_ShowNotLoaded) then
		Stubby.UnregisterFunctionHook("AuctionFrame_Show", Auctioneer_ShowNotLoaded);
	end

	-- Hook in new tooltip code
	Stubby.RegisterFunctionHook("EnhTooltip.AddTooltip", 100, Auctioneer.Tooltip.HookTooltip);

	-- Register our temporary command hook with stubby
	Stubby.RegisterBootCode("Auctioneer", "CommandHandler", [[
		local function cmdHandler(msg)
			local i,j, cmd, param = string.find(string.lower(msg), "^([^ ]+) (.+)$")
			if (not cmd) then cmd = string.lower(msg) end
			if (not cmd) then cmd = "" end
			if (not param) then param = "" end
			if (cmd == "load") then
				if (param == "") then
					Stubby.Print("Manually loading Auctioneer...")
					LoadAddOn("Auctioneer")
				elseif (param == "auctionhouse") then
					Stubby.Print("Setting Auctioneer to load when this character visits the auction house")
					Stubby.SetConfig("Auctioneer", "LoadType", param)
				elseif (param == "always") then
					Stubby.Print("Setting Auctioneer to always load for this character")
					Stubby.SetConfig("Auctioneer", "LoadType", param)
					LoadAddOn("Auctioneer")
				elseif (param == "never") then
					Stubby.Print("Setting Auctioneer to never load automatically for this character (you may still load manually)")
					Stubby.SetConfig("Auctioneer", "LoadType", param)
				else
					Stubby.Print("Your command was not understood")
				end
			else
				Stubby.Print("Auctioneer is currently not loaded.")
				Stubby.Print("  You may load it now by typing |cffffffff/auctioneer load|r")
				Stubby.Print("  You may also set your loading preferences for this character by using the following commands:")
				Stubby.Print("  |cffffffff/auctioneer load auctionhouse|r - Auctioneer will load when you visit the auction house")
				Stubby.Print("  |cffffffff/auctioneer load always|r - Auctioneer will always load for this character")
				Stubby.Print("  |cffffffff/auctioneer load never|r - Auctioneer will never load automatically for this character (you may still load it manually)")
			end
		end
		SLASH_AUCTIONEER1 = "/auctioneer"
		SLASH_AUCTIONEER2 = "/auction"
		SLASH_AUCTIONEER3 = "/auc"
		SlashCmdList["AUCTIONEER"] = cmdHandler
	]]);
	Stubby.RegisterBootCode("Auctioneer", "Triggers", [[
		function Auctioneer_CheckLoad()
			local loadType = Stubby.GetConfig("Auctioneer", "LoadType")
			if (loadType == "auctionhouse" or not loadType) then
				LoadAddOn("Auctioneer")
			end
		end
		function Auctioneer_ShowNotLoaded()
			BrowseNoResultsText:SetText("]].._AUCT('MesgNotLoaded')..[[");
		end
		local function onLoaded()
			Stubby.UnregisterAddOnHook("Blizzard_AuctionUI", "Auctioneer")
			if (not IsAddOnLoaded("Auctioneer")) then
				Stubby.RegisterFunctionHook("AuctionFrame_Show", 100, Auctioneer_ShowNotLoaded)
			end
		end
		Stubby.RegisterFunctionHook("AuctionFrame_LoadUI", 100, Auctioneer_CheckLoad)
		Stubby.RegisterAddOnHook("Blizzard_AuctionUI", "Auctioneer", onLoaded)
		local loadType = Stubby.GetConfig("Auctioneer", "LoadType")
		if (loadType == "always") then
			LoadAddOn("Auctioneer")
		else
			Stubby.Print("]].._AUCT('MesgNotLoaded')..[[");
		end
	]]);

	-- Saved for later logins, and run now so it works straight away this session.
	Stubby.RegisterBootCode("Auctioneer", "Glossary", glossaryBootCode);
	RunScript(glossaryBootCode);
end

Auctioneer.OnLoad = onLoad;

