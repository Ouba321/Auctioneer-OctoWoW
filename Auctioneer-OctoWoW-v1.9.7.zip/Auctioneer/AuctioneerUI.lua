--[[
	Auctioneer Addon for World of Warcraft(tm).
	Version: 3.6.1 (Platypus)
	Revision: $Id: AuctioneerUI.lua 735 2006-03-03 04:04:26Z vindicator $

	Auctioneer UI manager

	License:
		This program is free software; you can redistribute it and/or
		modify it under the terms of the GNU General Public License
		as published by the Free Software Foundation; either version 2
		of the License, or (at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program(see GPL.txt); if not, write to the Free Software
		Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
]]

-------------------------------------------------------------------------------
-- Data members
-------------------------------------------------------------------------------
CursorItem = nil;

MoneyTypeInfo["AUCTIONEER"] = {
	UpdateFunc = function()
		return this.staticMoney;
	end,

	collapse = 1,
	fixedWidth = 1,
	showSmallerCoins = 1
};

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctioneerUI_OnLoad()
	Stubby.RegisterFunctionHook("PickupContainerItem", 200, AuctioneerUI_PickupContainerItemHook)
end

-------------------------------------------------------------------------------
-- Called after Blizzard's AuctionFrameTab_OnClick() method.
-------------------------------------------------------------------------------
function AuctioneerUI_AuctionFrameTab_OnClickHook(_, _, index)
	-- Clicking Browse on the way from Post Auctions (still shown at this point) with an item in
	-- the slot shows that item's auctions, so the suggested price can be checked against what's
	-- for sale ("post-browse"). Only a click on the tab itself, which passes no index: opening
	-- the AH and Alt+Right-click searches switch to Browse with index 1. (Auctioneer-OctoWoW)
	local postItem = nil;
	if (not index and AuctionFramePost:IsVisible()) then postItem = AuctionFramePost:GetItemName(); end

	if (not index) then
		index = this:GetID();
	end

	-- Hide the Auctioneer tabs
	AuctionFrameSearch:Hide();
	AuctionFramePost:Hide();
	
	-- Show an Auctioneer tab if its the one clicked
	local tab = getglobal("AuctionFrameTab"..index);
	if (tab) then
		if (tab:GetName() == "AuctionFrameTabSearch") then
			AuctionFrameTopLeft:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-TopLeft");
			AuctionFrameTop:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-Top");
			AuctionFrameTopRight:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-TopRight");
			AuctionFrameBotLeft:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-BotLeft");
			AuctionFrameBot:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-Bot");
			AuctionFrameBotRight:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-BotRight");
			AuctionFrameSearch:Show();
		elseif (tab:GetName() == "AuctionFrameTabPost") then
			AuctionFrameTopLeft:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-TopLeft");
			AuctionFrameTop:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-Top");
			AuctionFrameTopRight:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-TopRight");
			AuctionFrameBotLeft:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-BotLeft");
			AuctionFrameBot:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-Bot");
			AuctionFrameBotRight:SetTexture("Interface\\AuctionFrame\\UI-AuctionFrame-Browse-BotRight");
			AuctionFramePost:Show();
		end
	end

	if (postItem and AuctionFrameBrowse:IsVisible() and Auctioneer.Command.GetFilter('post-browse')) then
		Auctioneer.Scanning.ShowItemOnBrowse(postItem);
	end
end

-------------------------------------------------------------------------------
-- Called after Blizzard's PickupContainerItem() method in order to capture
-- which item is on the cursor.
-------------------------------------------------------------------------------
function AuctioneerUI_PickupContainerItemHook(_, _, bag, slot)
	if (CursorHasItem()) then
		CursorItem = { bag = bag, slot = slot };
		--EnhTooltip.DebugPrint("Picked up item "..CursorItem.bag..", "..CursorItem.slot);
	else
		CursorItem = nil;
		--EnhTooltip.DebugPrint("Dropped item "..bag..", "..slot);
	end
	AuctioneerUI_GetCursorContainerItem();
end

-------------------------------------------------------------------------------
-- Gets the bag and slot number of the item on the cursor.
-------------------------------------------------------------------------------
function AuctioneerUI_GetCursorContainerItem()
	if (CursorHasItem() and CursorItem) then
		return CursorItem;
	end
	return nil;
end

-------------------------------------------------------------------------------
-- Auctions tab: Shift-click auctions to mark several, and Cancel Auction cancels them all
-- after one confirmation (Auctioneer-OctoWoW). A plain click selects one, as before.
-- Marks are list positions with each auction's details; a mark is dropped when the auction at
-- its position changes (sold, cancelled, bid on, the list renumbered). The cancels go out one
-- at a time, a moment apart, each auction found again by its details, since the list
-- renumbers after every cancel.
-------------------------------------------------------------------------------
local CANCEL_INTERVAL = 0.2;
local lMarked = {};			-- list position -> details of the auction marked there
local lCancelQueue = {};	-- details of each auction still to cancel
local lCancelSent = {};		-- positions cancelled since the list last changed
local lCancelTimer = 0;
-- Blizzard's own single selection counts only after a plain click: Shift-clicks and cancelling
-- the marked ones leave it pointing at an auction that was unmarked or has moved, which its
-- Cancel Auction would then cancel
local lSelectionTrusted = true;
-- the auction last clicked or Shift-clicked, where an Alt-click range starts, with its details
-- so a renumbered list doesn't start a range somewhere else
local lAnchor, lAnchorDetails;

local function auctionDetails(index)
	local name, _, count, _, _, _, minBid, _, buyout, bidAmount = GetAuctionItemInfo("owner", index);
	if (not name) then return nil; end
	return name.."|"..count.."|"..minBid.."|"..buyout.."|"..bidAmount;
end

-- The deposit an auction cost, for the cancel warning. The game doesn't say once it's posted,
-- so it's noted as you post (AuctioneerUI_RecordDepositHook), per realm and character, for a
-- few days. One posted before that is worked out from the item's vendor price and the time
-- left: Very Long means a 24 hour auction; otherwise it may have started longer than it looks,
-- so it's the smallest it could have been. Returns the deposit and whether it's exact, or nil.
local DEPOSIT_KEEP = 3 * 24 * 60 * 60;
local function depositKey(name, count, minBid, buyout)
	return Auctioneer.Util.GetAuctionKey().."|"..UnitName("player").."|"..name.."|"..count.."|"..minBid.."|"..buyout;
end

function AuctioneerUI_RecordDepositHook(_, _, minBid, buyout, duration)
	local name, _, count = GetAuctionSellItemInfo();
	if (not name or not count or not minBid or not duration or not CalculateAuctionDeposit) then return; end
	if (not AuctionConfig.deposits) then AuctionConfig.deposits = {}; end
	local now = time();
	for key, entry in pairs(AuctionConfig.deposits) do
		local _, _, at = string.find(entry, ";(%d+)$");
		if (not at or now - tonumber(at) > DEPOSIT_KEEP) then AuctionConfig.deposits[key] = nil; end
	end
	AuctionConfig.deposits[depositKey(name, count, minBid, buyout or 0)] = CalculateAuctionDeposit(duration)..";"..now;
end

function AuctioneerUI_AuctionDeposit(index)
	local name, _, count, _, _, _, minBid, _, buyout = GetAuctionItemInfo("owner", index);
	if (not name) then return nil; end
	local recorded = AuctionConfig.deposits and AuctionConfig.deposits[depositKey(name, count, minBid, buyout)];
	if (recorded) then
		local _, _, deposit = string.find(recorded, "^(%d+);");
		if (deposit) then return tonumber(deposit), true; end
	end
	local link = GetAuctionItemLink("owner", index);
	local itemID = link and EnhTooltip.BreakLink(link);
	if (not itemID or not AuctionFramePost_CalculateAuctionDeposit) then return nil; end
	local timeLeft = GetAuctionItemTimeLeft("owner", index);
	local duration = 120;
	if (timeLeft == 4) then duration = 1440; elseif (timeLeft == 3) then duration = 480; end
	local deposit = AuctionFramePost_CalculateAuctionDeposit(itemID, count, duration);
	if (not deposit) then return nil; end
	return deposit, (timeLeft == 4);
end

-- the warning's words: the marked auctions, their deposits and whether there's a bid cost
function AuctioneerUI_CancelWarningText(count, cost)
	local deposits, known, exact = 0, 0, true;
	for index in pairs(lMarked) do
		local deposit, isExact = AuctioneerUI_AuctionDeposit(index);
		if (deposit) then
			deposits = deposits + deposit;
			known = known + 1;
			if (not isExact) then exact = false; end
		else
			exact = false;
		end
	end
	local amount = "";
	if (known > 0) then
		amount = string.gsub(EnhTooltip.GetTextGSC(deposits, true, true), "%s+$", "");
		if (amount == "0") then amount = "0c"; end
		if (not exact) then amount = "at least "..amount; end
		amount = " ("..amount..")";
	end
	local text;
	if (count == 1) then
		text = "Cancel this auction? You lose its deposit"..amount;
	else
		text = "Cancel these "..count.." auctions? You lose their deposits"..amount;
	end
	if (cost == 0) then
		return text..".";
	elseif (count == 1) then
		return text..", and its bid costs you:";
	end
	return text..", and the bids on them cost you:";
end

-- how many marks are still on the auction they were put on, dropping the others; and what
-- cancelling them costs (5% of each bid, as for one)
function AuctioneerUI_MarkedAuctions()
	local count, cost = 0, 0;
	for index, details in pairs(lMarked) do
		if (auctionDetails(index) == details) then
			count = count + 1;
			local _, _, _, _, _, _, _, _, _, bidAmount = GetAuctionItemInfo("owner", index);
			cost = cost + math.floor(bidAmount * 0.05);
		else
			lMarked[index] = nil;
		end
	end
	return count, cost;
end

function AuctioneerUI_ClearMarkedAuctions()
	for index in pairs(lMarked) do lMarked[index] = nil; end
end

-- Blizzard's single selection, if it still counts: picked by a plain click, and still on the
-- auction clicked (the list renumbers when auctions sell or are cancelled, and the selection
-- stays on the position)
function AuctioneerUI_TrustedSelection()
	local selected = GetSelectedAuctionItem("owner");
	if (lSelectionTrusted and selected and selected > 0 and selected == lAnchor and auctionDetails(selected) == lAnchorDetails) then
		return selected;
	end
	return nil;
end

-- before Blizzard's AuctionsButton_OnClick: Shift-click marks or unmarks a row instead, and
-- Alt-click marks every auction from the last one clicked to this one (Cmd on a Mac keyboard,
-- if the game gets it as Alt; WoW only knows Shift, Ctrl and Alt)
function AuctioneerUI_AuctionsButtonOnClickHook(_, _, button)
	if (not button) then button = this; end
	local index = button:GetID() + FauxScrollFrame_GetOffset(AuctionsScrollFrame);
	local shift, alt = IsShiftKeyDown(), IsAltKeyDown();
	if (not shift and not alt) then
		AuctioneerUI_ClearMarkedAuctions();
		lSelectionTrusted = true;
		lAnchor, lAnchorDetails = index, auctionDetails(index);
		return;
	end
	-- the auction selected before counts as the first mark
	local selected = AuctioneerUI_TrustedSelection();
	if (AuctioneerUI_MarkedAuctions() == 0 and selected and selected ~= index) then
		lMarked[selected] = auctionDetails(selected);
	end
	lSelectionTrusted = false;
	if (alt and lAnchor and auctionDetails(lAnchor) == lAnchorDetails) then
		local first, last = math.min(lAnchor, index), math.max(lAnchor, index);
		for i = first, last do
			lMarked[i] = auctionDetails(i);
		end
	elseif (lMarked[index]) then
		lMarked[index] = nil;
		lAnchor, lAnchorDetails = index, auctionDetails(index);
	else
		lMarked[index] = auctionDetails(index);
		lAnchor, lAnchorDetails = index, auctionDetails(index);
	end
	CloseAuctionStaticPopups();
	StaticPopup_Hide("AUCTIONEER_CANCEL_AUCTIONS");
	AuctionFrameAuctions_Update();
	return "abort";
end

-- after Blizzard's AuctionFrameAuctions_Update: the marked rows lit, the Cancel button counting them
function AuctioneerUI_AuctionsUpdateHook()
	local count = AuctioneerUI_MarkedAuctions();
	if (count > 0 or not AuctioneerUI_TrustedSelection()) then
		local offset = FauxScrollFrame_GetOffset(AuctionsScrollFrame);
		for i = 1, NUM_AUCTIONS_TO_DISPLAY do
			local button = getglobal("AuctionsButton"..i);
			if (lMarked[offset + i]) then button:LockHighlight(); else button:UnlockHighlight(); end
		end
		if (count > 0) then
			AuctionsCancelAuctionButton:Enable();
		else
			AuctionsCancelAuctionButton:Disable();
		end
	end
	if (count > 1) then
		AuctionsCancelAuctionButton:SetText("Cancel "..count.." Auctions");
	else
		AuctionsCancelAuctionButton:SetText(CANCEL_AUCTION);
	end
end

function AuctioneerUI_CancelMarkedAuctions()
	for index, details in pairs(lMarked) do
		if (auctionDetails(index) == details) then table.insert(lCancelQueue, details); end
		lMarked[index] = nil;
	end
	lSelectionTrusted = false;
	lCancelSent = {};
	lCancelTimer = 0;
	local count = table.getn(lCancelQueue);
	if (count == 1) then
		Auctioneer.Util.ChatPrint("Auctioneer: cancelling 1 auction...");
	else
		Auctioneer.Util.ChatPrint("Auctioneer: cancelling "..count.." auctions...");
	end
	AuctioneerCancelQueueFrame:Show();
	AuctionFrameAuctions_Update();
end

-- one cancel per tick, while the auction house is open
function AuctioneerUI_CancelQueueOnUpdate(elapsed)
	lCancelTimer = lCancelTimer - (elapsed or 0);
	if (lCancelTimer > 0) then return; end
	lCancelTimer = CANCEL_INTERVAL;
	if (table.getn(lCancelQueue) == 0) then
		AuctioneerCancelQueueFrame:Hide();
		return;
	end
	if (not (AuctionFrame and AuctionFrame:IsVisible())) then
		local left = table.getn(lCancelQueue);
		lCancelQueue = {};
		AuctioneerCancelQueueFrame:Hide();
		Auctioneer.Util.ChatPrint("Auctioneer: the auction house closed, so "..left.." of the auctions weren't cancelled.");
		return;
	end
	local details = table.remove(lCancelQueue, 1);
	for index = 1, GetNumAuctionItems("owner") do
		if (not lCancelSent[index] and auctionDetails(index) == details) then
			lCancelSent[index] = true;
			CancelAuction(index);
			return;
		end
	end
	-- gone already (sold, or cancelled some other way)
end

function AuctioneerUI_SetupAuctionsTab()
	if (AuctioneerCancelQueueFrame) then return; end
	-- parented to UIParent, so it can tell when the AH has closed and stop
	local queue = CreateFrame("Frame", "AuctioneerCancelQueueFrame", UIParent);
	queue:Hide();
	queue:SetScript("OnUpdate", function() AuctioneerUI_CancelQueueOnUpdate(arg1); end);
	-- the owned list changed: positions renumbered, so earlier sends don't count any more
	queue:RegisterEvent("AUCTION_OWNED_LIST_UPDATE");
	queue:SetScript("OnEvent", function() lCancelSent = {}; end);

	StaticPopupDialogs["AUCTIONEER_CANCEL_AUCTIONS"] = {
		text = CANCEL_AUCTION_CONFIRMATION,
		button1 = ACCEPT,
		button2 = CANCEL,
		OnAccept = function() AuctioneerUI_CancelMarkedAuctions(); end,
		OnShow = function()
			local count, cost = AuctioneerUI_MarkedAuctions();
			MoneyFrame_Update(this:GetName().."MoneyFrame", cost);
			-- set here, like Blizzard's own warning: the popup takes its size after this
			getglobal(this:GetName().."Text"):SetText(AuctioneerUI_CancelWarningText(count, cost));
		end,
		hasMoneyFrame = 1,
		showAlert = 1,
		exclusive = 1,
		hideOnEscape = 1
	};

	Stubby.RegisterFunctionHook("AuctionsButton_OnClick", -50, AuctioneerUI_AuctionsButtonOnClickHook);
	-- before the item leaves the auction slot: what posting it costs
	Stubby.RegisterFunctionHook("StartAuction", -100, AuctioneerUI_RecordDepositHook);
	Stubby.RegisterFunctionHook("AuctionFrameAuctions_Update", 200, AuctioneerUI_AuctionsUpdateHook);
	AuctionsCancelAuctionButton:SetScript("OnClick", function()
		local selected = AuctioneerUI_TrustedSelection();
		if (AuctioneerUI_MarkedAuctions() == 0 and selected) then
			-- one selected the usual way: the same warning, so it shows the deposit too
			lMarked[selected] = auctionDetails(selected);
		end
		if (AuctioneerUI_MarkedAuctions() > 0) then
			StaticPopup_Show("AUCTIONEER_CANCEL_AUCTIONS");
		end
	end);
	-- leaving the tab clears the marks
	local onHide = AuctionFrameAuctions:GetScript("OnHide");
	AuctionFrameAuctions:SetScript("OnHide", function()
		AuctioneerUI_ClearMarkedAuctions();
		if (onHide) then onHide(); end
	end);
end

-------------------------------------------------------------------------------
-- Wrapper for UIDropDownMenu_SetSeletedID() that sets 'this' before calling
-- UIDropDownMenu_SetSelectedID().
-------------------------------------------------------------------------------
function AuctioneerDropDownMenu_SetSelectedID(dropdown, index)
	local oldThis = this;
	this = dropdown;
	local newThis = this;
	UIDropDownMenu_SetSelectedID(dropdown, index);
	-- Double check that the value of 'this' didn't change... this can screw us
	-- up and prevent the reason for this method!
	if (newThis ~= this) then
		EnhTooltip.DebugPrint("WARNING: The value of this changed during AuctioneerDropDownMenu_SetSelectedID()");
	end
	this = oldThis;
end

-------------------------------------------------------------------------------
-- Wrapper for UIDropDownMenu_Initialize() that sets 'this' before calling
-- UIDropDownMenu_Initialize().
-------------------------------------------------------------------------------
function AuctioneerDropDownMenu_Initialize(dropdown, func)
	-- Hide all the buttons to prevent any calls to Hide() inside
	-- UIDropDownMenu_Initialize() which will screw up the value of this.
	local button, dropDownList;
	for i = 1, UIDROPDOWNMENU_MAXLEVELS, 1 do
		dropDownList = getglobal("DropDownList"..i);
		if ( i >= UIDROPDOWNMENU_MENU_LEVEL or frame:GetName() ~= UIDROPDOWNMENU_OPEN_MENU ) then
			dropDownList.numButtons = 0;
			dropDownList.maxWidth = 0;
			for j=1, UIDROPDOWNMENU_MAXBUTTONS, 1 do
				button = getglobal("DropDownList"..i.."Button"..j);
				button:Hide();
			end
		end
	end

	-- Call the UIDropDownMenu_Initialize() after swapping in a value for 'this'.
	local oldThis = this;
	this = getglobal(dropdown:GetName().."Button");
	local newThis = this;
	UIDropDownMenu_Initialize(dropdown, func);
	-- Double check that the value of 'this' didn't change... this can screw us
	-- up and prevent the reason for this method!
	if (newThis ~= this) then
		EnhTooltip.DebugPrint("WARNING: The value of this changed during UIDropDownMenu_Initialize()");
	end
	this = oldThis;
end
