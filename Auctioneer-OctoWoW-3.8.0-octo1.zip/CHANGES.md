# Changes

Changes made to the original addons, as the GPL asks.

## Stubby 3.8.0-octo1 (2026-10-21)

- `Stubby/Stubby.lua`, `onLoaded()`: added
  `if not StubbyConfig then StubbyConfig = {} end` before the first use of `StubbyConfig`.
  This fixes `Stubby.lua:630: attempt to index global 'StubbyConfig' (a nil value)`, which
  happened when the saved settings file contained `StubbyConfig = nil`.
- `Stubby/Stubby.lua`: added a note about the modification to the header comment.
- `Stubby/Stubby.toc`: version changed from `3.8.0` to `3.8.0-octo1`.

## Repack

- Removed leftover `.svn` and `.DS_Store` folders and files from `EnhTooltip`.
- Auctioneer 3.6.1 and EnhTooltip 3.8.0 are otherwise unchanged.
