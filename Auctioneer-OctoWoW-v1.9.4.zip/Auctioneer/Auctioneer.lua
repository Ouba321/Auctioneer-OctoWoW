--[[
	Auctioneer
	Revision: $Id: Auctioneer.lua 844 2006-04-29 23:33:49Z aradan $
	Version: 3.6.1 (Platypus)
	Original version written by Norganna.
	Contributors: Araband

	This is an addon for World of Warcraft that adds statistical history to the auction data that is collected
	when the auction is scanned, so that you can easily determine what price
	you will be able to sell an item for at auction or at a vendor whenever you
	mouse-over an item in the game

	License:
		This program is free software; you can redistribute it and/or
		modify it under the terms of the GNU General Public License
		as published by the Free Software Foundation; either version 2
		of the License, or (at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program(see GPL.txt); if not, write to the Free Software
		Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
]]


Auctioneer.Version="3.6.1";
-- If you want to see debug messages, create a window called "Debug" within the client.
if (Auctioneer.Version == "<".."%version%>") then
	Auctioneer.Version = "3.5.DEV";
end

-- /auc-glossary explains the shorthand Auctioneer shows in chat, tooltips and the AH frames.
-- It's Stubby boot code like /auctioneer, so it also works before Auctioneer is loaded.
-- /auc-glossary <word> shows only the terms containing that word. (Auctioneer-OctoWoW)
local glossaryBootCode = [[
	local terms = {
		{ "AH", "Auction house." },
		{ "bb / bidbroker", "/auctioneer bb <silver>: auctions ending soon that you can win with a bid and resell for at least that much profit." },
		{ "BO", "Buyout: the price to buy an auction right away, without bidding." },
		{ "browse-sort", "How Browse lists are sorted when the AH opens: buyout (lowest first, the default), bid, or off. /auctioneer browse-sort bid switches to bids. Only the page on screen is sorted." },
		{ "broker", "/auctioneer broker <silver>: auctions you can buy out and resell for at least that much profit." },
		{ "compete", "/auctioneer compete <silver>: other players' auctions that are at least that much cheaper per item than yours." },
		{ "curBid", "The current highest bid on an auction." },
		{ "ea / each / For 1", "The price for a single item of a stack." },
		{ "historical / Last N", "Prices from all your past scans (the last N auctions seen)." },
		{ "HSP", "Highest Sellable Price: Auctioneer's suggested buyout, the most you can ask while still being the cheapest. Normally it undercuts the cheapest auction by 5%, or goes 2% under market price when nobody else is selling. See the pct- settings." },
		{ "in N's", "The stack size the item is usually sold in, e.g. [in 20's]." },
		{ "Market price", "The median buyout from your scans, or the average buyout if there's no median yet." },
		{ "Median", "The middle price of everything seen, so a few silly listings don't pull it around." },
		{ "min / minBid", "The minimum bid, which is also an auction's starting price." },
		{ "name-suggest", "Item names suggested as you type in the Browse Name box or a Search Auctions name box, your profession's reagents first (open your profession window so Auctioneer knows them). Click one to search, Tab fills in the top one. On by default; /auctioneer name-suggest off turns it off." },
		{ "No competition", "Nobody else was selling the item in your last scan." },
		{ "No data for HSP", "Not enough price data to suggest a price yet. Scan the item's category, or type a price yourself." },
		{ "pct-bidmarkdown", "Starting price is the suggested buyout minus this many percent. Default 20. Change it with /auctioneer pct-bidmarkdown <percent>, like the other pct- settings." },
		{ "pct-markup", "With no auction data at all, use the vendor price plus this many percent. Default 300. Needs the Informant addon." },
		{ "search-scan", "A search on the Search Auctions tab with an item name also runs an Item Scan for it: the list shows your saved scans at once, then what's for sale now. On by default; /auctioneer search-scan off searches only your saved scans." },
		{ "post-browse", "Going from Post Auctions to the Browse tab with an item in the slot searches Browse for it, so you can check the suggested price against what's for sale. On by default; /auctioneer post-browse off turns it off." },
		{ "post-scan", "Putting an item in the Post Auctions slot first runs an Item Scan for it, so its suggested prices are up to date. On by default; /auctioneer post-scan off turns it off." },
		{ "pct-maxover", "On the Post Auctions tab, a competitor priced above market is undercut too, but never more than this many percent over market. Default 200 (up to 3x market)." },
		{ "pct-maxless", "If the cheapest auction is more than this many percent under market price, don't chase it. Default 30." },
		{ "pct-nocomp", "Go this many percent under market price when nobody else is selling. Default 2." },
		{ "pct-underlow", "Undercut the cheapest auction by this many percent. Default 5." },
		{ "pct-undermkt", "When the cheapest auction is too cheap to chase, go this many percent under market price instead. Default 20." },
		{ "pl / percentless", "/auctioneer pl <percent>: buyouts at least that many percent under HSP." },
		{ "Prof", "Profit: what you'd make by reselling at HSP, minus what you pay." },
		{ "Seen N times", "How many auctions of the item your scans have recorded." },
		{ "Snapshot / last scan", "What was on the auction house during your latest scan." },
		{ "Snapshot low", "The cheapest buyout for the item in your latest scan." },
		{ "Undercut", "Listing a little cheaper than the cheapest competitor, so yours sells first." },
	}
	local function glossary(msg)
		local word = string.lower(string.gsub(msg or "", "^%s*(.-)%s*$", "%1"))
		local shown = 0
		for i = 1, table.getn(terms) do
			local term, text = terms[i][1], terms[i][2]
			if (word == "" or string.find(string.lower(term), word, 1, true)) then
				if (shown == 0) then
					DEFAULT_CHAT_FRAME:AddMessage("Auctioneer glossary (/auc-glossary <word> looks one up):", 1, 0.82, 0)
				end
				DEFAULT_CHAT_FRAME:AddMessage("|cffffffff"..term.."|r - "..text, 1, 0.82, 0)
				shown = shown + 1
			end
		end
		if (shown == 0) then
			DEFAULT_CHAT_FRAME:AddMessage("Auctioneer glossary: nothing matches \""..word.."\". Type /auc-glossary to see every term.", 1, 0.82, 0)
		end
	end
	SLASH_AUCTGLOSSARY1 = "/auc-glossary"
	SlashCmdList["AUCTGLOSSARY"] = glossary
]];

-- /auctioneer-help lists every /auctioneer command with what it does, grouped by topic, the new
-- ones included. Stubby boot code like /auc-glossary, so it works before Auctioneer is loaded.
-- /auctioneer-help <word> shows only the lines containing that word. (Auctioneer-OctoWoW)
local helpBootCode = [[
	local commands = {
		{ "Scanning" },
		{ "scan", "Scans the auction house: the categories ticked on the Browse tab, or everything. Runs now at the AH, or at your next visit. Same as the side panel's Scan button." },
		{ "scan resume", "Carries on with an unfinished scan from where it stopped, like the side panel's Resume button." },
		{ "finish off|logout|exit", "What happens when a scan finishes: nothing, log out, or quit the game." },
		{ "protect-window never|scan|always", "Keeps the AH window from closing by accident: never, during scans (default), or always." },
		{ "Finding bargains" },
		{ "broker <silver>", "Auctions from your last scan you can buy out and resell for at least that much profit." },
		{ "bidbroker <silver>", "Auctions ending soon you can win with a bid and resell for at least that much profit. Short: bb." },
		{ "percentless <percent>", "Auctions whose buyout is at least that many percent under the suggested price (HSP). Short: pl." },
		{ "compete <silver>", "Other players' auctions at least that much cheaper per item than yours." },
		{ "low [item]", "The cheapest buyout seen for an item. Shift+click the item into the command." },
		{ "med [item]", "The median buyout seen for an item." },
		{ "hsp [item]", "The price Auctioneer suggests for an item (highest sellable price)." },
		{ "Selling on the Post Auctions tab" },
		{ "post-scan on|off", "Putting an item in the slot runs an Item Scan for it first. On by default." },
		{ "post-browse on|off", "Clicking Browse from Post Auctions shows only the slotted item's auctions. On by default." },
		{ "update-price on|off", "Changing the buyout updates the starting price too." },
		{ "autofill on|off", "Fills in suggested prices when you put an item up for auction." },
		{ "auction-click on|off", "Alt+click an item in your bags to start an auction for it." },
		{ "auction-duration last|2h|8h|24h", "The auction length picked when the AH opens. Default 24h." },
		{ "warn-color on|off", "Shows the pricing note (Undercutting by 5%, ...) in colour." },
		{ "bid-limit <number>", "How many auctions the Search Auctions tab's Bid or Buyout button buys at most. Default 1." },
		{ "Pricing (/auc-glossary pct explains each)" },
		{ "pct-underlow <percent>", "Undercut the cheapest auction by this much. Default 5." },
		{ "pct-nocomp <percent>", "Go this much under market price when nobody else sells it. Default 2." },
		{ "pct-maxless <percent>", "Don't chase an auction more than this much under market price. Default 30." },
		{ "pct-undermkt <percent>", "Go this much under market price instead, when the cheapest is too far under it. Default 20." },
		{ "pct-maxover <percent>", "Undercut a pricier competitor, but never ask more than this much over market price. Default 200." },
		{ "pct-markup <percent>", "With no auction data, ask the vendor price plus this much. Default 300." },
		{ "pct-bidmarkdown <percent>", "The starting price is the buyout minus this much. Default 20." },
		{ "Browse and search" },
		{ "browse-sort buyout|bid|off", "How Browse lists are sorted when the AH opens: lowest buyout first (default), lowest bid first, or the game's order." },
		{ "name-suggest on|off", "Item names suggested as you type in the Browse and Search Auctions name boxes. On by default." },
		{ "search-scan on|off", "A search on the Search Auctions tab with an item name also scans the auction house for it: your saved scans show at once, then what's for sale now. On by default." },
		{ "Tooltips" },
		{ "on|off|toggle", "Auctioneer's lines in item tooltips." },
		{ "show-verbose on|off", "Averages and suggestions on several lines; off puts them on one." },
		{ "show-average on|off", "The item's average auction price." },
		{ "show-median on|off", "The item's median buyout." },
		{ "show-suggest on|off", "The item's suggested auction price." },
		{ "show-stats on|off", "How often the item gets bids and buyouts." },
		{ "show-link on|off", "The item's link ID." },
		{ "show-warning on|off", "A warning when a scanned page took too long because of lag." },
		{ "embed on|off", "Puts Auctioneer's lines inside the game's own tooltip." },
		{ "show-embed-blankline on|off", "A blank line before Auctioneer's lines when they're embedded." },
		{ "also <realm-faction>|opposite|home|neutral", "Also shows another realm's or faction's prices in tooltips." },
		{ "AskPrice (answering price questions in chat)" },
		{ "askprice on|off", "Answers price questions other players ask in chat." },
		{ "askprice vendor|party|guild|smart|ad on|off", "Vendor prices in the answers, answering in party or guild chat, SmartWords checking, and the AskPrice ad." },
		{ "askprice trigger <character>", "The character that starts a price question." },
		{ "Setup" },
		{ "load always|never|auctionhouse", "When Auctioneer loads for this character. Default: at the auction house." },
		{ "disable", "Stops Auctioneer loading by itself from your next login." },
		{ "locale <locale>", "The language of Auctioneer's messages." },
		{ "print-in <frame>", "Which chat window Auctioneer prints in, by name or number." },
		{ "default <option>|all", "Puts an option, or all of them, back to its default." },
		{ "clear [item]|all|snapshot", "Deletes saved data: an item's (Shift+click it in), everything, or the last scan's snapshot." },
		{ "help", "The original, shorter command list." },
		{ "/auc-glossary [word]", "What HSP, BO and the other shorthand mean." },
		{ "/auctioneer-help [word]", "This list. A word shows only the lines with it, like /auctioneer-help scan." },
	}
	local function help(msg)
		local word = string.lower(string.gsub(msg or "", "^%s*(.-)%s*$", "%1"))
		local heading, shown = nil, 0
		for i = 1, table.getn(commands) do
			local command, text = commands[i][1], commands[i][2]
			if (not text) then
				heading = command
			elseif (word == "" or string.find(string.lower(command.." "..text), word, 1, true)) then
				if (shown == 0) then
					DEFAULT_CHAT_FRAME:AddMessage("Auctioneer commands (/auctioneer-help <word> shows only the lines with it):", 1, 0.82, 0)
				end
				if (heading) then
					DEFAULT_CHAT_FRAME:AddMessage(heading, 0.4, 0.8, 1)
					heading = nil
				end
				if (string.sub(command, 1, 1) ~= "/") then command = "/auctioneer "..command end
				DEFAULT_CHAT_FRAME:AddMessage("  |cffffffff"..command.."|r - "..text, 1, 0.82, 0)
				shown = shown + 1
			end
		end
		if (shown == 0) then
			DEFAULT_CHAT_FRAME:AddMessage("Auctioneer: no command matches \""..word.."\". Type /auctioneer-help to see them all.", 1, 0.82, 0)
		end
	end
	SLASH_AUCTIONEERHELP1 = "/auctioneer-help"
	SlashCmdList["AUCTIONEERHELP"] = help
]];

-- Remembers which reagents this character's recipes need, from the profession windows, for the
-- item name suggestions (AucSuggest.lua). Being Stubby boot code, it also runs while Auctioneer
-- isn't loaded, and it saves in Stubby's per-character settings. A recipe that still gives skill
-- points counts most: orange 3, yellow 2, green 1, grey not at all. (Auctioneer-OctoWoW)
local reagentsBootCode = [[
	local weights = { optimal = 3, medium = 2, easy = 1 }
	local function learn(skill, count, kindOf, numReagents, reagentName)
		if (not skill or skill == "UNKNOWN" or not count or count == 0) then return end
		local items = {}
		for i = 1, count do
			local weight = weights[kindOf(i)]
			if (weight) then
				for r = 1, (numReagents(i) or 0) do
					local name = reagentName(i, r)
					if (name and weight > (items[name] or 0)) then items[name] = weight end
				end
			end
		end
		local all = Stubby.GetConfig("Auctioneer", "Reagents")
		if (type(all) ~= "table") then all = {} end
		all[skill] = items
		Stubby.SetConfig("Auctioneer", "Reagents", all)
	end
	local function tradeSkill()
		learn(GetTradeSkillLine(), GetNumTradeSkills(),
			function(i) local _, kind = GetTradeSkillInfo(i) return kind end,
			GetTradeSkillNumReagents, function(i, r) return (GetTradeSkillReagentInfo(i, r)) end)
	end
	local function craft()
		learn(GetCraftDisplaySkillLine(), GetNumCrafts(),
			function(i) local _, _, kind = GetCraftInfo(i) return kind end,
			GetCraftNumReagents, function(i, r) return (GetCraftReagentInfo(i, r)) end)
	end
	Stubby.RegisterEventHook("TRADE_SKILL_SHOW", "AuctioneerReagents", tradeSkill)
	Stubby.RegisterEventHook("TRADE_SKILL_UPDATE", "AuctioneerReagents", tradeSkill)
	Stubby.RegisterEventHook("CRAFT_SHOW", "AuctioneerReagents", craft)
	Stubby.RegisterEventHook("CRAFT_UPDATE", "AuctioneerReagents", craft)
]];

local function onLoad()
	-- Unhook some boot triggers if necessary.
	-- These might not exist on initial loading or if an addon depends on Auctioneer
	if (Auctioneer_CheckLoad) then
		Stubby.UnregisterFunctionHook("AuctionFrame_LoadUI", Auctioneer_CheckLoad);
	end
	if (Auctioneer_ShowNotLoaded) then
		Stubby.UnregisterFunctionHook("AuctionFrame_Show", Auctioneer_ShowNotLoaded);
	end

	-- Hook in new tooltip code
	Stubby.RegisterFunctionHook("EnhTooltip.AddTooltip", 100, Auctioneer.Tooltip.HookTooltip);

	-- Register our temporary command hook with stubby
	Stubby.RegisterBootCode("Auctioneer", "CommandHandler", [[
		local function cmdHandler(msg)
			local i,j, cmd, param = string.find(string.lower(msg), "^([^ ]+) (.+)$")
			if (not cmd) then cmd = string.lower(msg) end
			if (not cmd) then cmd = "" end
			if (not param) then param = "" end
			if (cmd == "load") then
				if (param == "") then
					Stubby.Print("Manually loading Auctioneer...")
					LoadAddOn("Auctioneer")
				elseif (param == "auctionhouse") then
					Stubby.Print("Setting Auctioneer to load when this character visits the auction house")
					Stubby.SetConfig("Auctioneer", "LoadType", param)
				elseif (param == "always") then
					Stubby.Print("Setting Auctioneer to always load for this character")
					Stubby.SetConfig("Auctioneer", "LoadType", param)
					LoadAddOn("Auctioneer")
				elseif (param == "never") then
					Stubby.Print("Setting Auctioneer to never load automatically for this character (you may still load manually)")
					Stubby.SetConfig("Auctioneer", "LoadType", param)
				else
					Stubby.Print("Your command was not understood")
				end
			else
				Stubby.Print("Auctioneer is currently not loaded.")
				Stubby.Print("  You may load it now by typing |cffffffff/auctioneer load|r")
				Stubby.Print("  You may also set your loading preferences for this character by using the following commands:")
				Stubby.Print("  |cffffffff/auctioneer load auctionhouse|r - Auctioneer will load when you visit the auction house")
				Stubby.Print("  |cffffffff/auctioneer load always|r - Auctioneer will always load for this character")
				Stubby.Print("  |cffffffff/auctioneer load never|r - Auctioneer will never load automatically for this character (you may still load it manually)")
			end
		end
		SLASH_AUCTIONEER1 = "/auctioneer"
		SLASH_AUCTIONEER2 = "/auction"
		SLASH_AUCTIONEER3 = "/auc"
		SlashCmdList["AUCTIONEER"] = cmdHandler
	]]);
	Stubby.RegisterBootCode("Auctioneer", "Triggers", [[
		function Auctioneer_CheckLoad()
			local loadType = Stubby.GetConfig("Auctioneer", "LoadType")
			if (loadType == "auctionhouse" or not loadType) then
				LoadAddOn("Auctioneer")
			end
		end
		function Auctioneer_ShowNotLoaded()
			BrowseNoResultsText:SetText("]].._AUCT('MesgNotLoaded')..[[");
		end
		local function onLoaded()
			Stubby.UnregisterAddOnHook("Blizzard_AuctionUI", "Auctioneer")
			if (not IsAddOnLoaded("Auctioneer")) then
				Stubby.RegisterFunctionHook("AuctionFrame_Show", 100, Auctioneer_ShowNotLoaded)
			end
		end
		Stubby.RegisterFunctionHook("AuctionFrame_LoadUI", 100, Auctioneer_CheckLoad)
		Stubby.RegisterAddOnHook("Blizzard_AuctionUI", "Auctioneer", onLoaded)
		local loadType = Stubby.GetConfig("Auctioneer", "LoadType")
		if (loadType == "always") then
			LoadAddOn("Auctioneer")
		else
			Stubby.Print("]].._AUCT('MesgNotLoaded')..[[");
		end
	]]);

	-- Saved for later logins, and run now so it works straight away this session.
	Stubby.RegisterBootCode("Auctioneer", "Glossary", glossaryBootCode);
	RunScript(glossaryBootCode);
	Stubby.RegisterBootCode("Auctioneer", "Reagents", reagentsBootCode);
	RunScript(reagentsBootCode);
	Stubby.RegisterBootCode("Auctioneer", "Help", helpBootCode);
	RunScript(helpBootCode);
end

Auctioneer.OnLoad = onLoad;

