--[[
	Auctioneer Addon for World of Warcraft(tm).
	Version: 3.6.1 (Platypus)
	Revision: $Id: AuctionFrameSearch.lua 857 2006-05-11 01:21:25Z luke1410 $

	Auctioneer Search Auctions tab

	License:
		This program is free software; you can redistribute it and/or
		modify it under the terms of the GNU General Public License
		as published by the Free Software Foundation; either version 2
		of the License, or (at your option) any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program(see GPL.txt); if not, write to the Free Software
		Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
--]]

local TIME_LEFT_NAMES =
{
	AUCTION_TIME_LEFT1, -- Short
	AUCTION_TIME_LEFT2, -- Medium
	AUCTION_TIME_LEFT3, -- Long
	AUCTION_TIME_LEFT4  -- Very Long
};

local AUCTION_STATUS_UNKNOWN = 1;
local AUCTION_STATUS_HIGH_BIDDER = 2;
local AUCTION_STATUS_NOT_FOUND = 3;
local AUCTION_STATUS_BIDDING = 4;

-- Sorting by buyout, an auction without one (0) counts as the highest price: last when cheapest
-- comes first, as it can't be bought outright. (Auctioneer-OctoWoW)
local NO_BUYOUT = 1e100;
local function buyoutValue(value)
	if (value == 0) then return NO_BUYOUT; end
	return value;
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctionFrameSearch_OnLoad()
	-- Methods
	this.SearchBids = AuctionFrameSearch_SearchBids;
	this.SearchBuyouts = AuctionFrameSearch_SearchBuyouts;
	this.SearchCompetition = AuctionFrameSearch_SearchCompetition;
	this.SearchPlain = AuctionFrameSearch_SearchPlain;
	this.SelectResultByIndex = AuctionFrameSearch_SelectResultByIndex;
	this.RefreshAfterItemScan = AuctionFrameSearch_RefreshAfterItemScan;
	this.RefreshDuringItemScan = AuctionFrameSearch_RefreshDuringItemScan;

	-- Controls
	this.savedSearchDropDown = getglobal(this:GetName().."SavedSearchDropDown");
	this.searchDropDown = getglobal(this:GetName().."SearchDropDown");
	this.bidFrame = getglobal(this:GetName().."Bid");
	this.buyoutFrame = getglobal(this:GetName().."Buyout");
	this.competeFrame = getglobal(this:GetName().."Compete");
	this.plainFrame = getglobal(this:GetName().."Plain");
	this.resultsList = getglobal(this:GetName().."List");
	this.bidButton = getglobal(this:GetName().."BidButton");
	this.buyoutButton = getglobal(this:GetName().."BuyoutButton");
	this.pendingBidStatusText = getglobal(this:GetName().."PendingBidStatusText");

	-- Data members
	this.results = {};
	this.resultsType = nil;
	this.selectedResult = nil;

	-- Initialize the Search drop down
	AuctioneerDropDownMenu_Initialize(this.searchDropDown, AuctionFrameSearch_SearchDropDown_Initialize);
	-- the Item search lists every auction for a name; the Bids and Buyouts searches list
	-- bargains only, and starting on Bids made a search look like it found nothing
	-- (Auctioneer-OctoWoW)
	AuctionFrameSearch_SearchDropDownItem_SetSelectedID(this.searchDropDown, 4);

	-- Configure the logical columns
	this.logicalColumns =
	{
		Quantity =
		{
			title = _AUCT("UiQuantityHeader");
			dataType = "Number";
			valueFunc = (function(record) return record.count end);
			alphaFunc = AuctionFrameSearch_GetAuctionAlpha;
			compareAscendingFunc = (function(record1, record2) return record1.count < record2.count end);
			compareDescendingFunc = (function(record1, record2) return record1.count > record2.count end);
		},
		Name =
		{
			title = _AUCT("UiNameHeader");
			dataType = "String";
			valueFunc = (function(record) return record.name end);
			colorFunc = AuctionFrameSearch_GetItemColor;
			alphaFunc = AuctionFrameSearch_GetAuctionAlpha;
			compareAscendingFunc = (function(record1, record2) return record1.name < record2.name end);
			compareDescendingFunc = (function(record1, record2) return record1.name > record2.name end);
		},
		TimeLeft =
		{
			title = _AUCT("UiTimeLeftHeader");
			dataType = "String";
			valueFunc = (function(record) return Auctioneer.Util.GetTimeLeftString(record.timeLeft) end);
			alphaFunc = AuctionFrameSearch_GetAuctionAlpha;
			compareAscendingFunc = (function(record1, record2) return record1.timeLeft < record2.timeLeft end);
			compareDescendingFunc = (function(record1, record2) return record1.timeLeft > record2.timeLeft end);
		},
		Bid =
		{
			title = _AUCT("UiBidHeader");
			dataType = "Money";
			valueFunc = (function(record) return record.bid end);
			alphaFunc = AuctionFrameSearch_GetAuctionAlpha;
			compareAscendingFunc = (function(record1, record2) return record1.bid < record2.bid end);
			compareDescendingFunc = (function(record1, record2) return record1.bid > record2.bid end);
		},
		BidPer =
		{
			title = _AUCT("UiBidPerHeader");
			dataType = "Money";
			valueFunc = (function(record) return record.bidPer end);
			alphaFunc = AuctionFrameSearch_GetAuctionAlpha;
			compareAscendingFunc = (function(record1, record2) return record1.bidPer < record2.bidPer end);
			compareDescendingFunc = (function(record1, record2) return record1.bidPer > record2.bidPer end);
		},
		Buyout =
		{
			title = _AUCT("UiBuyoutHeader");
			dataType = "Money";
			valueFunc = (function(record) return record.buyout end);
			alphaFunc = AuctionFrameSearch_GetAuctionAlpha;
			compareAscendingFunc = (function(record1, record2) return buyoutValue(record1.buyout) < buyoutValue(record2.buyout) end);
			compareDescendingFunc = (function(record1, record2) return buyoutValue(record1.buyout) > buyoutValue(record2.buyout) end);
		},
		BuyoutPer =
		{
			title = _AUCT("UiBuyoutPerHeader");
			dataType = "Money";
			valueFunc = (function(record) return record.buyoutPer end);
			alphaFunc = AuctionFrameSearch_GetAuctionAlpha;
			compareAscendingFunc = (function(record1, record2) return buyoutValue(record1.buyoutPer) < buyoutValue(record2.buyoutPer) end);
			compareDescendingFunc = (function(record1, record2) return buyoutValue(record1.buyoutPer) > buyoutValue(record2.buyoutPer) end);
		},
		Profit =
		{
			title = _AUCT("UiProfitHeader");
			dataType = "Money";
			valueFunc = (function(record) return record.profit end);
			alphaFunc = AuctionFrameSearch_GetAuctionAlpha;
			compareAscendingFunc = (function(record1, record2) return record1.profit < record2.profit end);
			compareDescendingFunc = (function(record1, record2) return record1.profit > record2.profit end);
		},
		ProfitPer =
		{
			title = _AUCT("UiProfitPerHeader");
			dataType = "Money";
			valueFunc = (function(record) return record.profitPer end);
			alphaFunc = AuctionFrameSearch_GetAuctionAlpha;
			compareAscendingFunc = (function(record1, record2) return record1.profitPer < record2.profitPer end);
			compareDescendingFunc = (function(record1, record2) return record1.profitPer > record2.profitPer end);
		},
		PercentLess =
		{
			title = _AUCT("UiPercentLessHeader");
			dataType = "Number";
			valueFunc = (function(record) return record.percentLess end);
			alphaFunc = AuctionFrameSearch_GetAuctionAlpha;
			compareAscendingFunc = (function(record1, record2) return record1.percentLess < record2.percentLess end);
			compareDescendingFunc = (function(record1, record2) return record1.percentLess > record2.percentLess end);
		},
		ItemLevel =
		{
			title = _AUCT("UiItemLevelHeader");
			dataType = "Number";
			valueFunc = (function(record) return record.level end);
			alphaFunc = AuctionFrameSearch_GetAuctionAlpha;
			compareAscendingFunc = (function(record1, record2) return record1.level < record2.level end);
			compareDescendingFunc = (function(record1, record2) return record1.level > record2.level end);
		},
	};

	-- Configure the bid search physical columns
	this.bidSearchPhysicalColumns =
	{
		{
			width = 50;
			logicalColumn = this.logicalColumns.Quantity;
			logicalColumns = { this.logicalColumns.Quantity };
			sortAscending = true;
		},
		{
			width = 160;
			logicalColumn = this.logicalColumns.Name;
			logicalColumns = { this.logicalColumns.Name };
			sortAscending = true;
		},
		{
			width = 90;
			logicalColumn = this.logicalColumns.TimeLeft;
			logicalColumns = { this.logicalColumns.TimeLeft };
			sortAscending = true;
		},
		{
			width = 130;
			logicalColumn = this.logicalColumns.Bid;
			logicalColumns =
			{
				this.logicalColumns.Bid,
				this.logicalColumns.BidPer
			};
			sortAscending = true;
		},
		{
			width = 130;
			logicalColumn = this.logicalColumns.Profit;
			logicalColumns =
			{
				this.logicalColumns.Profit,
				this.logicalColumns.ProfitPer,
				this.logicalColumns.Buyout,
				this.logicalColumns.BuyoutPer
			};
			sortAscending = true;
		},
		{
			width = 50;
			logicalColumn = this.logicalColumns.PercentLess;
			logicalColumns =
			{
				this.logicalColumns.PercentLess
			};
			sortAscending = true;
		},
	};

	-- Configure the buyout search physical columns
	this.buyoutSearchPhysicalColumns =
	{
		{
			width = 50;
			logicalColumn = this.logicalColumns.Quantity;
			logicalColumns = { this.logicalColumns.Quantity };
			sortAscending = true;
		},
		{
			width = 250;
			logicalColumn = this.logicalColumns.Name;
			logicalColumns = { this.logicalColumns.Name };
			sortAscending = true;
		},
		{
			width = 130;
			logicalColumn = this.logicalColumns.Buyout;
			logicalColumns =
			{
				this.logicalColumns.Bid,
				this.logicalColumns.BidPer,
				this.logicalColumns.Buyout,
				this.logicalColumns.BuyoutPer
			};
			sortAscending = true;
		},
		{
			width = 130;
			logicalColumn = this.logicalColumns.Profit;
			logicalColumns =
			{
				this.logicalColumns.Bid,
				this.logicalColumns.BidPer,
				this.logicalColumns.Profit,
				this.logicalColumns.ProfitPer
			};
			sortAscending = true;
		},
		{
			width = 50;
			logicalColumn = this.logicalColumns.PercentLess;
			logicalColumns =
			{
				this.logicalColumns.PercentLess
			};
			sortAscending = true;
		},
	};

	-- Configure the compete search physical columns
	this.competeSearchPhysicalColumns =
	{
		{
			width = 50;
			logicalColumn = this.logicalColumns.Quantity;
			logicalColumns = { this.logicalColumns.Quantity };
			sortAscending = true;
		},
		{
			width = 250;
			logicalColumn = this.logicalColumns.Name;
			logicalColumns = { this.logicalColumns.Name };
			sortAscending = true;
		},
		{
			width = 130;
			logicalColumn = this.logicalColumns.Bid;
			logicalColumns =
			{
				this.logicalColumns.Bid,
				this.logicalColumns.BidPer
			};
			sortAscending = true;
		},
		{
			width = 130;
			logicalColumn = this.logicalColumns.Buyout;
			logicalColumns =
			{
				this.logicalColumns.Buyout,
				this.logicalColumns.BuyoutPer
			};
			sortAscending = true;
		},
		{
			width = 50;
			logicalColumn = this.logicalColumns.PercentLess;
			logicalColumns =
			{
				this.logicalColumns.PercentLess
			};
			sortAscending = true;
		},
	};

	-- Configure the plain search physical columns. Its prices are per item to begin with, so
	-- stacks of different sizes compare (Auctioneer-OctoWoW).
	this.plainSearchPhysicalColumns =
	{
		{
			width = 50;
			logicalColumn = this.logicalColumns.Quantity;
			logicalColumns = { this.logicalColumns.Quantity };
			sortAscending = true;
		},
		{
			width = 160;
			logicalColumn = this.logicalColumns.Name;
			logicalColumns = { this.logicalColumns.Name };
			sortAscending = true;
		},
		{
			width = 90;
			logicalColumn = this.logicalColumns.TimeLeft;
			logicalColumns = { this.logicalColumns.TimeLeft };
			sortAscending = true;
		},
		{
			width = 130;
			logicalColumn = this.logicalColumns.BidPer;
			logicalColumns =
			{
				this.logicalColumns.Bid,
				this.logicalColumns.BidPer,
				this.logicalColumns.Buyout,
				this.logicalColumns.BuyoutPer
			};
			sortAscending = true;
		},
		{
			width = 130;
			logicalColumn = this.logicalColumns.BuyoutPer;
			logicalColumns =
			{
				this.logicalColumns.Profit,
				this.logicalColumns.ProfitPer,
				this.logicalColumns.Buyout,
				this.logicalColumns.BuyoutPer
			};
			sortAscending = true;
		},
		{
			width = 50;
			logicalColumn = this.logicalColumns.PercentLess;
			logicalColumns =
			{
				this.logicalColumns.PercentLess,
				this.logicalColumns.ItemLevel
			};
			sortAscending = true;
		},
	};


	-- Initialize the list to show nothing at first.
	ListTemplate_Initialize(this.resultsList, this.results, this.results);
	this:SelectResultByIndex(nil);

	AuctionFrameSearch_SetupLayout(this);
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctionFrameSearch_OnShow()
	AuctionFrameSearch_UpdatePendingBidStatus(this);
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
AUCTIONEER_SEARCH_TYPES = {}
function AuctionFrameSearch_SearchDropDown_Initialize()
	local dropdown = this:GetParent();
	local frame = dropdown:GetParent();

	AUCTIONEER_SEARCH_TYPES[1] = _AUCT("UiSearchTypeBids");
	AUCTIONEER_SEARCH_TYPES[2] = _AUCT("UiSearchTypeBuyouts");
	AUCTIONEER_SEARCH_TYPES[3] = _AUCT("UiSearchTypeCompetition");
	AUCTIONEER_SEARCH_TYPES[4] = _AUCT("UiSearchTypePlain");

	for i=1, 4 do
		UIDropDownMenu_AddButton({
			text = AUCTIONEER_SEARCH_TYPES[i],
			func = AuctionFrameSearch_SearchDropDownItem_OnClick,
			owner = dropdown
		})
	end
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctionFrameSearch_MinQualityDropDown_Initialize()
	local dropdown = this:GetParent();
	local frame = dropdown:GetParent();

	for i=0, 6 do
		UIDropDownMenu_AddButton({
			text = getglobal("ITEM_QUALITY"..i.."_DESC"),
			func = AuctionFrameSearch_MinQualityDropDownItem_OnClick,
			value = i,
			owner = dropdown
		});
	end
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctionFrameSearch_SavedSearchDropDownItem_OnClick()
	local frame = this.owner:GetParent();
	if (this:GetID() == 1) then
		AuctionFrameSearch_SelectSavedSearch(frame, nil);
	else
		AuctionFrameSearch_LoadSavedSearch(frame, this.value);
	end
end

-------------------------------------------------------------------------------
-- Fills in a saved search's search type and settings, and shows its name in the Saved Searches
-- dropdown (Auctioneer-OctoWoW: by name; the name box it used is gone).
-------------------------------------------------------------------------------
function AuctionFrameSearch_LoadSavedSearch(frame, name)
	local frameName = frame:GetName();
	local searchData = AuctionConfig.SavedSearches and AuctionConfig.SavedSearches[name];
	if (not searchData) then return; end
	local searchParams = Auctioneer.Util.Split(searchData, "\t");

	local searchType = tonumber(searchParams[1])
	getglobal(frameName.."SearchDropDown").selectedID = searchType;
	getglobal(frameName.."SearchDropDownText"):SetText(AUCTIONEER_SEARCH_TYPES[searchType]);

	frame.bidFrame:Hide();
	frame.buyoutFrame:Hide();
	frame.competeFrame:Hide();
	frame.plainFrame:Hide();
	if (searchType == 1) then
		-- Bid search
		MoneyInputFrame_SetCopper(getglobal(frameName.."BidMinProfit"), tonumber(searchParams[2]))

		getglobal(frameName.."BidMinPercentLessEdit"):SetText(searchParams[3])

		local timeLeft = tonumber(searchParams[4]) or 2
		AuctioneerDropDownMenu_Initialize(getglobal(frameName.."BidTimeLeftDropDown"), AuctionFrameSearch_TimeLeftDropDown_Initialize);
		AuctioneerDropDownMenu_SetSelectedID(getglobal(frameName.."BidTimeLeftDropDown"), timeLeft);

		AuctionFrameSearch_LoadCategory(getglobal(frameName.."BidCategoryDropDown"), searchParams[5]);

		local quality = tonumber(searchParams[6]) or 1
		AuctioneerDropDownMenu_Initialize(getglobal(frameName.."BidMinQualityDropDown"), AuctionFrameSearch_MinQualityDropDown_Initialize);
		AuctioneerDropDownMenu_SetSelectedID(getglobal(frameName.."BidMinQualityDropDown"), quality);

		getglobal(frameName.."BidSearchEdit"):SetText(searchParams[7] or "")

		frame.bidFrame:Show();
	elseif (searchType == 2) then
		-- Buyout search
		MoneyInputFrame_SetCopper(getglobal(frameName.."BuyoutMinProfit"), tonumber(searchParams[2]))

		getglobal(frameName.."BuyoutMinPercentLessEdit"):SetText(searchParams[3])

		AuctionFrameSearch_LoadCategory(getglobal(frameName.."BuyoutCategoryDropDown"), searchParams[4]);

		local quality = tonumber(searchParams[5]) or 1
		AuctioneerDropDownMenu_Initialize(getglobal(frameName.."BuyoutMinQualityDropDown"), AuctionFrameSearch_MinQualityDropDown_Initialize);
		AuctioneerDropDownMenu_SetSelectedID(getglobal(frameName.."BuyoutMinQualityDropDown"), quality);

		getglobal(frameName.."BuyoutSearchEdit"):SetText(searchParams[6] or "")

		frame.buyoutFrame:Show();
	elseif (searchType == 3) then
		-- Compete search
		MoneyInputFrame_SetCopper(getglobal(frameName.."CompeteUndercut"), tonumber(searchParams[2]))

		frame.competeFrame:Show();
	elseif (searchType == 4) then
		-- Plain search
		MoneyInputFrame_SetCopper(getglobal(frameName.."PlainMaxPrice"), tonumber(searchParams[2]))

		-- (v1.8 and before set up the dropdown's label here instead, which stopped with an error)
		AuctionFrameSearch_LoadCategory(getglobal(frameName.."PlainCategoryDropDown"), searchParams[3]);

		local quality = tonumber(searchParams[4]) or 1
		AuctioneerDropDownMenu_Initialize(getglobal(frameName.."PlainMinQualityDropDown"), AuctionFrameSearch_MinQualityDropDown_Initialize);
		AuctioneerDropDownMenu_SetSelectedID(getglobal(frameName.."PlainMinQualityDropDown"), quality);

		getglobal(frameName.."PlainSearchEdit"):SetText(searchParams[5] or "")

		frame.plainFrame:Show();
	end
	AuctionFrameSearch_SelectSavedSearch(frame, name);
end

-- the saved search shown in the dropdown (nil for none); one saved without a name (before
-- Auctioneer-OctoWoW v1.9) shows as "(no name)"
function AuctionFrameSearch_SelectSavedSearch(frame, name)
	local dropdown = getglobal(frame:GetName().."SavedSearchDropDown");
	frame.selectedSavedSearch = name;
	dropdown.selectedID = nil;
	local label = name or "";
	if (name == "") then label = "(no name)"; end
	UIDropDownMenu_SetText(label, dropdown);
end

-------------------------------------------------------------------------------
-- The list ticks the search shown by its name, not its row number, so saving or deleting one
-- doesn't move the tick to another (Auctioneer-OctoWoW).
-------------------------------------------------------------------------------
function AuctionFrameSearch_SavedSearchDropDown_Initialize()
	local dropdown = AuctionFrameSearchSavedSearchDropDown
	local frame = dropdown:GetParent()
	local current = frame.selectedSavedSearch;
	dropdown.selectedID = nil;

	UIDropDownMenu_AddButton({
		text = "",
		checked = (current == nil) and 1 or nil,
		func = AuctionFrameSearch_SavedSearchDropDownItem_OnClick,
		owner = dropdown
	});
	local names = {};
	for name in pairs(AuctionConfig.SavedSearches or {}) do
		table.insert(names, name);
	end
	table.sort(names);
	for i = 1, table.getn(names) do
		local name = names[i];
		local text = name;
		if (name == "") then text = "(no name)"; end
		UIDropDownMenu_AddButton({
			text = text,
			value = name,
			checked = (name == current) and 1 or nil,
			func = AuctionFrameSearch_SavedSearchDropDownItem_OnClick,
			owner = dropdown
		});
	end
end


-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctionFrameSearch_MinQualityDropDownItem_OnClick()
	local index = this:GetID();
	local dropdown = this.owner;
	AuctioneerDropDownMenu_SetSelectedID(dropdown, index);
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctionFrameSearch_SearchDropDownItem_OnClick()
	local index = this:GetID();
	local dropdown = this.owner;
	AuctionFrameSearch_SearchDropDownItem_SetSelectedID(dropdown, index);
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctionFrameSearch_SearchDropDownItem_SetSelectedID(dropdown, index)
	local frame = dropdown:GetParent();
	frame.bidFrame:Hide();
	frame.buyoutFrame:Hide();
	frame.competeFrame:Hide();
	frame.plainFrame:Hide();
	if (index == 1) then
		frame.bidFrame:Show();
	elseif (index == 2) then
		frame.buyoutFrame:Show();
	elseif (index == 3) then
		frame.competeFrame:Show();
	elseif (index == 4) then
		frame.plainFrame:Show();
	end
	AuctioneerDropDownMenu_SetSelectedID(dropdown, index);
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctionFrameSearch_RemoveSearchButton_OnClick(button)
	-- Delete (Auctioneer-OctoWoW): the saved search shown in the dropdown
	local frame = button:GetParent();
	local name = frame.selectedSavedSearch;
	if (not name or not AuctionConfig.SavedSearches or not AuctionConfig.SavedSearches[name]) then
		Auctioneer.Util.ChatPrint("Auctioneer: pick a saved search in the list to delete first.");
		return;
	end
	AuctionConfig.SavedSearches[name] = nil;
	AuctionFrameSearch_SelectSavedSearch(frame, nil);
	if (name == "") then name = "(no name)"; end
	Auctioneer.Util.ChatPrint("Auctioneer: deleted the saved search \""..name.."\".");
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctionFrameSearch_SaveSearchButton_OnClick(button)
	AuctionFrameSearch_SaveCurrentSearch(button:GetParent());
end

-------------------------------------------------------------------------------
-- The name a search is saved under, now the Save button sits by each Search button with no
-- name box (Auctioneer-OctoWoW): its item, with the search type unless it's an Item search
-- ("Citrine", "Citrine (Bids)"); with no item, the search type and category ("Buyouts: Weapon").
-- Saving the same again replaces it.
-------------------------------------------------------------------------------
local SEARCH_TYPE_STRINGS = { "UiSearchTypeBids", "UiSearchTypeBuyouts", "UiSearchTypeCompetition", "UiSearchTypePlain" };
function AuctionFrameSearch_SavedSearchName(searchType, itemName, categoryDropDown)
	local typeName = _AUCT(SEARCH_TYPE_STRINGS[searchType] or SEARCH_TYPE_STRINGS[4]);
	itemName = string.gsub(itemName or "", "^%s*(.-)%s*$", "%1");
	if (itemName ~= "") then
		if (searchType == 4) then return itemName; end
		return itemName.." ("..typeName..")";
	end
	local category = categoryDropDown and getglobal(categoryDropDown:GetName().."Text"):GetText();
	if (category and category ~= "") then return typeName..": "..category; end
	return typeName;
end

function AuctionFrameSearch_SaveCurrentSearch(frame)
	local frameName = frame:GetName();
	local searchType = UIDropDownMenu_GetSelectedID(getglobal(frameName.."SearchDropDown"));
	local searchData, itemName, categoryDropDown;
	if (searchType == 1) then
		-- Bid-based search
		categoryDropDown = getglobal(frameName.."BidCategoryDropDown");
		itemName = getglobal(frameName.."BidSearchEdit"):GetText();
		searchData = string.format("%d\t%d\t%s\t%d\t%s\t%d\t%s",
			searchType,
			MoneyInputFrame_GetCopper(getglobal(frameName.."BidMinProfit")),
			getglobal(frameName.."BidMinPercentLessEdit"):GetText(),
			UIDropDownMenu_GetSelectedID(getglobal(frameName.."BidTimeLeftDropDown")) or 2,
			AuctionFrameSearch_CategorySaveText(categoryDropDown),
			UIDropDownMenu_GetSelectedID(getglobal(frameName.."BidMinQualityDropDown")) or 1,
			itemName
		);
	elseif (searchType == 2) then
		-- Buyout-based search
		categoryDropDown = getglobal(frameName.."BuyoutCategoryDropDown");
		itemName = getglobal(frameName.."BuyoutSearchEdit"):GetText();
		searchData = string.format("%d\t%d\t%s\t%s\t%d\t%s",
			searchType,
			MoneyInputFrame_GetCopper(getglobal(frameName.."BuyoutMinProfit")),
			getglobal(frameName.."BuyoutMinPercentLessEdit"):GetText(),
			AuctionFrameSearch_CategorySaveText(categoryDropDown),
			UIDropDownMenu_GetSelectedID(getglobal(frameName.."BuyoutMinQualityDropDown")) or 1,
			itemName
		);
	elseif (searchType == 3) then
		-- Compete-based search
		searchData = string.format("%d\t%d",
			searchType,
			MoneyInputFrame_GetCopper(getglobal(frameName.."CompeteUndercut"))
		);
	elseif (searchType == 4) then
		-- Plain-based search
		categoryDropDown = getglobal(frameName.."PlainCategoryDropDown");
		itemName = getglobal(frameName.."PlainSearchEdit"):GetText();
		searchData = string.format("%d\t%d\t%s\t%d\t%s",
			searchType,
			MoneyInputFrame_GetCopper(getglobal(frameName.."PlainMaxPrice")),
			AuctionFrameSearch_CategorySaveText(categoryDropDown),
			UIDropDownMenu_GetSelectedID(getglobal(frameName.."PlainMinQualityDropDown")) or 1,
			itemName
		);
	end
	if (not searchData) then return; end

	local name = AuctionFrameSearch_SavedSearchName(searchType, itemName, categoryDropDown);
	if (not AuctionConfig.SavedSearches) then
		AuctionConfig.SavedSearches = {}
	end
	AuctionConfig.SavedSearches[name] = searchData
	AuctionFrameSearch_SelectSavedSearch(frame, name);
	Auctioneer.Util.ChatPrint("Auctioneer: saved the search \""..name.."\".");
end

-------------------------------------------------------------------------------
-- The top row is the Saved Searches dropdown and a Delete button; each search type has a Save
-- button next to its Search button; the line under the results stops before the Bid button.
-- (Auctioneer-OctoWoW, from a player's suggestion)
-------------------------------------------------------------------------------
function AuctionFrameSearch_SetupLayout(frame)
	local name = frame:GetName();
	getglobal(name.."SaveSearchEdit"):Hide();
	getglobal(name.."SaveSearchButton"):Hide();
	local dropdown = getglobal(name.."SavedSearchDropDown");
	for _, part in ipairs({ "Left", "Middle", "Right", "Text" }) do
		getglobal(dropdown:GetName()..part):Show();
	end
	dropdown:ClearAllPoints();
	dropdown:SetPoint("LEFT", name.."SavedSearchText", "RIGHT", -8, -3);
	UIDropDownMenu_SetWidth(160, dropdown);
	getglobal(dropdown:GetName().."Text"):SetJustifyH("LEFT");
	UIDropDownMenu_SetText("", dropdown);
	local delete = getglobal(name.."RemoveSearchButton");
	delete:ClearAllPoints();
	delete:SetPoint("LEFT", dropdown, "RIGHT", -10, 3);
	delete:SetText("Delete");

	frame.pendingBidStatusText:SetWidth(375);
	frame.pendingBidStatusText:SetHeight(14);
	frame.pendingBidStatusText:SetJustifyH("LEFT");

	-- Search and Save the same width, together as wide as the item box above them (its border
	-- reaches a little past its frame, which starts 5 in)
	for _, mode in ipairs({ "Bid", "Buyout", "Compete", "Plain" }) do
		local modeFrame = getglobal(name..mode);
		local searchButton = getglobal(name..mode.."SearchButton");
		searchButton:SetWidth(76);
		searchButton:ClearAllPoints();
		searchButton:SetPoint("BOTTOMLEFT", modeFrame, "BOTTOMLEFT", -2, 10);
		local save = CreateFrame("Button", name..mode.."SaveButton", modeFrame, "UIPanelButtonTemplate");
		save:SetWidth(76);
		save:SetHeight(22);
		save:SetPoint("LEFT", searchButton, "RIGHT", 4, 0);
		save:SetText("Save");
		save:SetScript("OnClick", function() AuctionFrameSearch_SaveCurrentSearch(this:GetParent():GetParent()); end);
	end
end

-------------------------------------------------------------------------------
-- The Bid button has been clicked
-------------------------------------------------------------------------------
function AuctionFrameSearch_BidButton_OnClick(button)
	local frame = button:GetParent();
	local result = frame.selectedResult;
	if (result and result.name and result.count and result.bid) then
		result.status = AUCTION_STATUS_BIDDING;
		result.pendingBidCount = result.pendingBidCount + 1;
		local bidLimit = Auctioneer.Command.GetFilterVal('bid-limit');
		local context = { frame = frame, auction = result };
		AucBidManager.BidAuction(result.bid, result.signature, bidLimit, AuctionFrameSearch_OnBidResult, context);
		AuctionFrameSearch_UpdateButtons(frame);
		AuctionFrameSearch_UpdatePendingBidStatus(frame);
		ListTemplateScrollFrame_Update(getglobal(frame.resultsList:GetName().."ScrollFrame"));
	end
end

-------------------------------------------------------------------------------
-- The Buyout button has been clicked.
-------------------------------------------------------------------------------
function AuctionFrameSearch_BuyoutButton_OnClick(button)
	local frame = button:GetParent();
	local result = frame.selectedResult;
	if (result and result.name and result.count and result.buyout) then
		result.status = AUCTION_STATUS_BIDDING;
		result.pendingBidCount = result.pendingBidCount + 1;
		local bidLimit = Auctioneer.Command.GetFilterVal('bid-limit');
		local context = { frame = frame, auction = result };
		AucBidManager.BidAuction(result.buyout, result.signature, bidLimit, AuctionFrameSearch_OnBidResult, context);
		AuctionFrameSearch_UpdateButtons(frame);
		AuctionFrameSearch_UpdatePendingBidStatus(frame);
		ListTemplateScrollFrame_Update(getglobal(frame.resultsList:GetName().."ScrollFrame"));
	end
end

-------------------------------------------------------------------------------
-- Updates the pending bid status text
-------------------------------------------------------------------------------
function AuctionFrameSearch_UpdatePendingBidStatus(frame)
	local count = AucBidManager.GetRequestCount();
	if (count == 1) then
		frame.pendingBidStatusText:SetText(_AUCT('UiPendingBidInProgress'));
	elseif (count > 1) then
		local output = string.format(_AUCT('UiPendingBidsInProgress'), count);
		frame.pendingBidStatusText:SetText(output);
	elseif (frame.pendingBidStatusText:GetText() ~= "") then
		frame.pendingBidStatusText:SetText(_AUCT('UiNoPendingBids'));
	end
end

-------------------------------------------------------------------------------
-- Returns the item color for the specified result
-------------------------------------------------------------------------------
function AuctionFrameSearch_GetItemColor(result)
	_, _, rarity = GetItemInfo(result.item);
	if (rarity) then
		return ITEM_QUALITY_COLORS[rarity];
	end
	return { r = 1.0, g = 1.0, b = 1.0 };
end

-------------------------------------------------------------------------------
-- Perform a bid search (aka bidBroker)
-------------------------------------------------------------------------------
function AuctionFrameSearch_SearchBids(frame, minProfit, minPercentLess, maxTimeLeft, category, minQuality, itemName, exact)
	-- Create the content from auctioneer.
	frame.results = {};
	local itemNames = Auctioneer.Util.Split(itemName, "|");
	local bidWorthyAuctions = Auctioneer.Filter.QuerySnapshot(Auctioneer.Filter.BidBrokerFilter, minProfit, maxTimeLeft, category, minQuality, itemNames, exact);
	if (bidWorthyAuctions) then
		local player = UnitName("player");
		for pos,a in pairs(bidWorthyAuctions) do
			if (a.owner ~= player) then
				local id,rprop,enchant,name, count,min,buyout,uniq = Auctioneer.Core.GetItemSignature(a.signature);
				local itemKey = id .. ":" .. rprop..":"..enchant;
				local hsp, seenCount = Auctioneer.Statistic.GetHSP(itemKey, Auctioneer.Util.GetAuctionKey());
				local currentBid = Auctioneer.Statistic.GetCurrentBid(a.signature);
				-- rounding down the hsp, to get a better selling price
				local hspBuyout = Auctioneer.Statistic.RoundDownTo95(hsp * count);
				local percentLess = 100 - math.floor(100 * currentBid / (hspBuyout));
				if (percentLess >= minPercentLess) then
					local auction = {};
					auction.id = id;
					auction.item = string.format("item:%s:%s:%s:0", id, enchant, rprop);
					auction.link = a.itemLink;
					auction.name = name;
					auction.count = count;
					auction.owner = a.owner;
					auction.timeLeft = a.timeLeft;
					auction.bid = currentBid;
					auction.bidPer = math.floor(auction.bid / count);
					auction.buyout = buyout;
					auction.buyoutPer = math.floor(auction.buyout / count);
					auction.profit = hspBuyout - currentBid;
					auction.profitPer = math.floor(auction.profit / count);
					auction.percentLess = percentLess;
					auction.signature = a.signature;
					auction.dirty = (a.dirty == "1");
					auction.lastSeen = a.lastSeenTime;
					if (a.highBidder) then
						auction.status = AUCTION_STATUS_HIGH_BIDDER;
					else
						auction.status = AUCTION_STATUS_UNKNOWN;
					end
					auction.pendingBidCount = 0;
					table.insert(frame.results, auction);
				end
			end
		end
	end

	-- Hand the updated results to the list.
	frame.resultsType = "BidSearch";
	frame:SelectResultByIndex(nil);
	ListTemplate_Initialize(frame.resultsList, frame.bidSearchPhysicalColumns, frame.auctioneerListLogicalColumns);
	ListTemplate_SetContent(frame.resultsList, frame.results);
	-- most profit first, ending soonest first among equals (Auctioneer-OctoWoW; sorting a column
	-- a second time turns it to highest first)
	ListTemplate_Sort(frame.resultsList, 3);
	ListTemplate_Sort(frame.resultsList, 5);
	ListTemplate_Sort(frame.resultsList, 5);
	AuctionFrameSearch_ShowResultsAge(frame, AuctionFrameSearch_NoBargainText(frame, category, minQuality, itemNames, exact));
end

-------------------------------------------------------------------------------
-- Perform a buyout search (aka percentLess)
-------------------------------------------------------------------------------
function AuctionFrameSearch_SearchBuyouts(frame, minProfit, minPercentLess, category, minQuality, itemName, exact)
	-- Create the content from auctioneer.
	frame.results = {};
	local itemNames = Auctioneer.Util.Split(itemName, "|");
	local buyoutWorthyAuctions = Auctioneer.Filter.QuerySnapshot(Auctioneer.Filter.PercentLessFilter, minPercentLess, category, minQuality, itemNames, exact);
	if (buyoutWorthyAuctions) then
		local player = UnitName("player");
		for pos,a in pairs(buyoutWorthyAuctions) do
			if (a.owner ~= player) then
				local id,rprop,enchant,name,count,min,buyout,uniq = Auctioneer.Core.GetItemSignature(a.signature);
				local itemKey = id .. ":" .. rprop..":"..enchant;
				local hsp, seenCount = Auctioneer.Statistic.GetHSP(itemKey, Auctioneer.Util.GetAuctionKey());
				-- rounding down the hsp, to get a better selling price
				local hspBuyout = Auctioneer.Statistic.RoundDownTo95(hsp * count);
				local profit = hspBuyout - buyout;
				if (profit >= minProfit) then
					local auction = {};
					auction.id = id;
					auction.item = string.format("item:%s:%s:%s:0", id, enchant, rprop);
					auction.link = a.itemLink;
					auction.name = name;
					auction.count = count;
					auction.owner = a.owner;
					auction.timeLeft = a.timeLeft;
					auction.buyout = buyout;
					auction.buyoutPer = math.floor(auction.buyout / count);
					auction.profit = profit;
					auction.profitPer = math.floor(auction.profit / count);
					auction.percentLess = 100 - math.floor(100 * buyout / hspBuyout);
					auction.signature = a.signature;
					auction.dirty = (a.dirty == "1");
					auction.lastSeen = a.lastSeenTime;
					if (a.highBidder) then
						auction.status = AUCTION_STATUS_HIGH_BIDDER;
					else
						auction.status = AUCTION_STATUS_UNKNOWN;
					end
					auction.pendingBidCount = 0;
					table.insert(frame.results, auction);
				end
			end
		end
	end

	-- Hand the updated content to the list.
	frame.resultsType = "BuyoutSearch";
	frame:SelectResultByIndex(nil);
	ListTemplate_Initialize(frame.resultsList, frame.buyoutSearchPhysicalColumns, frame.auctioneerListLogicalColumns);
	ListTemplate_SetContent(frame.resultsList, frame.results);
	-- most profit first (Auctioneer-OctoWoW); it was by % less, the smallest first
	ListTemplate_Sort(frame.resultsList, 4);
	ListTemplate_Sort(frame.resultsList, 4);
	AuctionFrameSearch_ShowResultsAge(frame, AuctionFrameSearch_NoBargainText(frame, category, minQuality, itemNames, exact));
end

-------------------------------------------------------------------------------
-- Perform a competition search (aka compete)
-------------------------------------------------------------------------------
function AuctionFrameSearch_SearchCompetition(frame, minUndercut)
	-- Create the content from auctioneer.
	frame.results = {};

	-- Get the highest prices for my auctions.
	local myAuctions = Auctioneer.Filter.QuerySnapshot(Auctioneer.Filter.AuctionOwnerFilter, UnitName("player"));
	local myHighestPrices = {}
	local id,rprop,enchant,name,count,min,buyout,uniq,itemKey,competingAuctions,currentBid,buyoutForOne,bidForOne,bidPrice,myBuyout,buyPrice,myPrice,priceLess,lessPrice,output;
	if (myAuctions) then
		for pos,a in pairs(myAuctions) do
			id,rprop,enchant, name, count,min,buyout,uniq = Auctioneer.Core.GetItemSignature(a.signature);
			if (count > 1) then buyout = buyout/count; end
			itemKey = id .. ":" .. rprop..":"..enchant;
			if (not myHighestPrices[itemKey]) or (myHighestPrices[itemKey] < buyout) then
				myHighestPrices[itemKey] = buyout;
			end
		end
	end

	-- Search for competing auctions less than mine.
	competingAuctions = Auctioneer.Filter.QuerySnapshot(Auctioneer.Filter.CompetingFilter, minUndercut, myHighestPrices);
	if (competingAuctions) then
		table.sort(competingAuctions, Auctioneer.Statistic.ProfitComparisonSort);
		for pos,a in pairs(competingAuctions) do
			local id,rprop,enchant,name,count,min,buyout,uniq = Auctioneer.Core.GetItemSignature(a.signature);
			local itemKey = id .. ":" .. rprop..":"..enchant;
			local myBuyout = myHighestPrices[itemKey];
			local currentBid = Auctioneer.Statistic.GetCurrentBid(a.signature);

			local auction = {};
			auction.id = id;
			auction.item = string.format("item:%s:%s:%s:0", id, enchant, rprop);
			auction.link = a.itemLink;
			auction.name = name;
			auction.count = count;
			auction.owner = a.owner;
			auction.timeLeft = a.timeLeft;
			auction.bid = currentBid;
			auction.bidPer = math.floor(auction.bid / count);
			auction.buyout = buyout;
			auction.buyoutPer = math.floor(auction.buyout / count);
			auction.percentLess = math.floor(((myBuyout - auction.buyoutPer) / myBuyout) * 100);
			auction.signature = a.signature;
			auction.dirty = (a.dirty == "1");
			auction.lastSeen = a.lastSeenTime;
			if (a.highBidder) then
				auction.status = AUCTION_STATUS_HIGH_BIDDER;
			else
				auction.status = AUCTION_STATUS_UNKNOWN;
			end
			auction.pendingBidCount = 0;
			table.insert(frame.results, auction);
		end
	end

	-- Hand the updated content to the list.
	frame.resultsType = "CompeteSearch";
	frame:SelectResultByIndex(nil);
	ListTemplate_Initialize(frame.resultsList, frame.competeSearchPhysicalColumns, frame.auctioneerListLogicalColumns);
	ListTemplate_SetContent(frame.resultsList, frame.results);
	AuctionFrameSearch_ShowResultsAge(frame);
end

-------------------------------------------------------------------------------
-- Perform a plain search
-------------------------------------------------------------------------------
function AuctionFrameSearch_SearchPlain(frame, maxPrice, category, minQuality, itemName, exact)
	-- Create the content from auctioneer.
	frame.results = {};
	local itemNames = Auctioneer.Util.Split(itemName, "|");
	local bidWorthyAuctions = Auctioneer.Filter.QuerySnapshot(Auctioneer.Filter.PlainFilter, maxPrice, category, minQuality, itemNames, exact);
	if (bidWorthyAuctions) then
		local player = UnitName("player");
		for pos,a in pairs(bidWorthyAuctions) do
			if (a.owner ~= player) then
				local id,rprop,enchant,name, count,min,buyout,uniq = Auctioneer.Core.GetItemSignature(a.signature);
				local itemKey = id .. ":" .. rprop..":"..enchant;
				local hsp, seenCount = Auctioneer.Statistic.GetHSP(itemKey, Auctioneer.Util.GetAuctionKey());
				local currentBid = Auctioneer.Statistic.GetCurrentBid(a.signature);
				-- rounding down the hsp, to get a better selling price
				local hspBuyout = Auctioneer.Statistic.RoundDownTo95(hsp * count);
				local percentLess = 100 - math.floor(100 * currentBid / hspBuyout);

				local _,_,_,iLevel = GetItemInfo(id);

				local auction = {};
				auction.id = id;
				auction.item = string.format("item:%s:%s:%s:0", id, enchant, rprop);
				auction.link = a.itemLink;
				auction.level = iLevel;
				auction.name = name;
				auction.count = count;
				auction.owner = a.owner;
				auction.timeLeft = a.timeLeft;
				auction.bid = currentBid;
				auction.bidPer = math.floor(auction.bid / count);
				auction.buyout = buyout;
				auction.buyoutPer = math.floor(auction.buyout / count);
				auction.profit = hspBuyout - currentBid;
				auction.profitPer = math.floor(auction.profit / count);
				auction.percentLess = percentLess;
				auction.signature = a.signature;
				auction.dirty = (a.dirty == "1");
				auction.lastSeen = a.lastSeenTime;
				if (a.highBidder) then
					auction.status = AUCTION_STATUS_HIGH_BIDDER;
				else
					auction.status = AUCTION_STATUS_UNKNOWN;
				end
				auction.pendingBidCount = 0;
				table.insert(frame.results, auction);
			end
		end
	end

	-- Hand the updated results to the list.
	frame.resultsType = "PlainSearch";
	frame:SelectResultByIndex(nil);
	ListTemplate_Initialize(frame.resultsList, frame.plainSearchPhysicalColumns, frame.auctioneerListLogicalColumns);
	ListTemplate_SetContent(frame.resultsList, frame.results);
	-- cheapest per item first, by buyout and then bid (Auctioneer-OctoWoW); it was by time left
	ListTemplate_Sort(frame.resultsList, 4);
	ListTemplate_Sort(frame.resultsList, 5);
	AuctionFrameSearch_ShowResultsAge(frame);
end

-------------------------------------------------------------------------------
-- The results come from your scans, not the live auction house, so the line under them says
-- how many there are and how long ago they were seen. (Auctioneer-OctoWoW)
-------------------------------------------------------------------------------
function AuctionFrameSearch_AgeText(seconds, noAgo)
	local text;
	if (seconds < 60) then
		if (noAgo) then return "now"; end
		return "just now";
	end
	local minutes = math.floor(seconds / 60);
	if (minutes < 60) then
		text = minutes.." min";
	elseif (minutes < 48 * 60) then
		text = math.floor(minutes / 60).." h";
	else
		text = math.floor(minutes / 1440).." days";
	end
	if (noAgo) then return text; end
	return text.." ago";
end

function AuctionFrameSearch_ShowResultsAge(frame, emptyText)
	local count = table.getn(frame.results);
	local newest, oldest;
	for i = 1, count do
		local seen = frame.results[i].lastSeen;
		if (seen) then
			if (not newest or seen > newest) then newest = seen; end
			if (not oldest or seen < oldest) then oldest = seen; end
		end
	end
	local text;
	if (count == 0) then
		text = emptyText or "Nothing found in your scans.";
	else
		if (count == 1) then text = "1 auction"; else text = count.." auctions"; end
		if (newest) then
			local now = time();
			if (newest - oldest < 60) then
				text = text..", seen "..AuctionFrameSearch_AgeText(now - newest);
			else
				text = text..", seen "..AuctionFrameSearch_AgeText(now - newest, true).." to "..AuctionFrameSearch_AgeText(now - oldest);
			end
		end
	end
	frame.pendingBidStatusText:SetText(text);
end

-- When a Bids or Buyouts search for an item comes up empty, there may still be auctions of it,
-- just none a bargain by the search's settings; the line under the list says so (Auctioneer-
-- OctoWoW). Nothing when there are results, or no item name.
function AuctionFrameSearch_NoBargainText(frame, category, minQuality, itemNames, exact)
	if (table.getn(frame.results) > 0 or not itemNames) then return nil; end
	local player = UnitName("player");
	local count = 0;
	local auctions = Auctioneer.Filter.QuerySnapshot(Auctioneer.Filter.PlainFilter, 0, category, minQuality, itemNames, exact);
	for _, a in pairs(auctions or {}) do
		if (a.owner ~= player) then count = count + 1; end
	end
	if (count == 0) then return nil; end
	if (count == 1) then return "1 auction found, not a bargain by these settings."; end
	return count.." auctions found, none a bargain by these settings.";
end

-------------------------------------------------------------------------------
-- An Item Scan has ended: an Item search waiting for it shows its results now.
-- (Auctioneer-OctoWoW)
-------------------------------------------------------------------------------
function AuctionFrameSearch_RefreshAfterItemScan(frame, name)
	local pending = frame.pendingItemSearch;
	if (not pending or pending.name ~= name) then return; end
	frame.pendingItemSearch = nil;
	pending.run();
end

-- A page of that Item Scan is in: the list shows everything found so far, and fills in as the
-- scan goes on (Auctioneer-OctoWoW)
function AuctionFrameSearch_RefreshDuringItemScan(frame, name)
	local pending = frame.pendingItemSearch;
	if (not pending or pending.name ~= name) then return; end
	pending.run();
	frame.pendingBidStatusText:SetText(AuctionFrameSearch_ScanningText(name, table.getn(frame.results)));
end

function AuctionFrameSearch_ScanningText(name, count)
	local text = "Scanning the AH for "..name.."...";
	if (count > 0) then text = text.." "..count.." found so far"; end
	return text;
end

-------------------------------------------------------------------------------
-- Runs a search on your saved scans straight away, so a recent scan fills the list at once.
-- With one item name it also scans the auction house for it ("search-scan") and runs again on
-- what that finds; not while another scan runs, or for a name scanned in the last minute. A Bid
-- or Buyout pressed meanwhile waits for the scan. (Auctioneer-OctoWoW)
-------------------------------------------------------------------------------
function AuctionFrameSearch_Search(search, itemName, run)
	search.pendingItemSearch = nil;
	run();
	if (itemName and not string.find(itemName, "|", 1, true) and Auctioneer.Command.GetFilter('search-scan')
			and AuctionFrame:IsVisible() and not Auctioneer.Scanning.IsScanningRequested
			and not Auctioneer.Scanning.ItemScannedRecently(itemName, 60)) then
		search.pendingItemSearch = { name = itemName, run = run };
		search.pendingBidStatusText:SetText(AuctionFrameSearch_ScanningText(itemName, table.getn(search.results)));
		Auctioneer.Scanning.RequestItemScan(itemName, true);
	end
end


-------------------------------------------------------------------------------
-- Select a search result by index.
-------------------------------------------------------------------------------
function AuctionFrameSearch_SelectResultByIndex(frame, index)
	if (index and index <= table.getn(frame.results) and frame.resultsType) then
		-- Select the item
		frame.selectedResult = frame.results[index];
		ListTemplate_SelectRow(frame.resultsList, index);
	else
		-- Clear the selection
		frame.selectedResult = nil;
		ListTemplate_SelectRow(frame.resultsList, nil);
	end

	AuctionFrameSearch_UpdateButtons(frame);
end

-------------------------------------------------------------------------------
-- Update the enabled/disabled state of the Bid and Buyout buttons
-------------------------------------------------------------------------------
function AuctionFrameSearch_UpdateButtons(frame)
	if (frame.selectedResult) then
		if (frame.selectedResult.status == AUCTION_STATUS_UNKNOWN) then
			if (frame.resultsType == "BidSearch") then
				frame.bidButton:Enable();
				frame.buyoutButton:Disable();
			elseif (frame.resultsType == "BuyoutSearch") then
				frame.bidButton:Disable();
				frame.buyoutButton:Enable();
			elseif (frame.resultsType == "CompeteSearch") then
				frame.bidButton:Enable();
				frame.buyoutButton:Enable();
			elseif (frame.resultsType == "PlainSearch") then
				frame.bidButton:Enable();
				frame.buyoutButton:Enable();
			else
				frame.bidButton:Disable();
				frame.buyoutButton:Disable();
			end
		else
			frame.bidButton:Disable();
			frame.buyoutButton:Disable();
		end
	else
		frame.bidButton:Disable();
		frame.buyoutButton:Disable();
	end
end

-------------------------------------------------------------------------------
-- An item in the list is moused over.
-------------------------------------------------------------------------------
function AuctionFrameSearch_ListItem_OnEnter(row)
	local frame = this:GetParent():GetParent();
	local results = frame.results;
	if (results and row <= table.getn(results)) then
		local result = results[row];
		if (result) then
			local _, link, rarity = GetItemInfo(result.item);
			if (link) then
				local name = result.name;
				local count = result.count;
				GameTooltip:SetOwner(this, "ANCHOR_RIGHT");
				GameTooltip:SetHyperlink(link);
				-- when your scans saw it, and whether it may be gone (Auctioneer-OctoWoW)
				if (result.lastSeen) then
					GameTooltip:AddLine("Seen "..AuctionFrameSearch_AgeText(time() - result.lastSeen), 0.6, 0.6, 0.6);
				end
				if (result.dirty) then
					GameTooltip:AddLine("Possibly gone: your unfinished scan hasn't seen it again.", 1, 0.5, 0.25, 1);
				end
				GameTooltip:Show();
				EnhTooltip.TooltipCall(GameTooltip, name, result.link, rarity, count);
			end
		end
	end
end

-------------------------------------------------------------------------------
-- An item in the list is clicked.
-------------------------------------------------------------------------------
function AuctionFrameSearch_ListItem_OnClick(row)
	local frame = this:GetParent():GetParent();

	-- Select the item clicked.
	frame:SelectResultByIndex(row);

	-- Bid or buyout the item if the alt key is down.
	if (frame.resultsType and IsAltKeyDown()) then
		if (IsShiftKeyDown()) then
			-- Bid or buyout the item.
			if (frame.resultsType == "BidSearch") then
				AuctionFrameSearch_BidButton_OnClick(frame.bidButton);

			elseif (frame.resultsType == "BuyoutSearch") then
				AuctionFrameSearch_BuyoutButton_OnClick(frame.buyoutButton);
			end

		else
			-- Search for the item and switch to the Browse tab.
			BrowseName:SetText(frame.results[row].name)
			BrowseMinLevel:SetText("")
			BrowseMaxLevel:SetText("")
			AuctionFrameBrowse.selectedInvtype = nil
			AuctionFrameBrowse.selectedInvtypeIndex = nil
			AuctionFrameBrowse.selectedClass = nil
			AuctionFrameBrowse.selectedClassIndex = nil
			AuctionFrameBrowse.selectedSubclass = nil
			AuctionFrameBrowse.selectedSubclassIndex = nil
			AuctionFrameFilters_Update()
			IsUsableCheckButton:SetChecked(0)
			UIDropDownMenu_SetSelectedValue(BrowseDropDown, -1)
			AuctionFrameBrowse_Search()
			AuctionFrameTab_OnClick(1);
		end

	--Thanks to Miravlix (from irc://irc.datavertex.com/cosmostesters) for the following codeblocks.
	elseif (IsControlKeyDown()) then
		DressUpItemLink(frame.results[row].item);

	elseif (IsShiftKeyDown() and ChatFrameEditBox:IsVisible()) then
		-- Trim leading whitespace
		ChatFrameEditBox:Insert(string.gsub(frame.results[row].link, " *(.*)", "%1"));
	end
end

-------------------------------------------------------------------------------
-- Initialize the content of a Category dropdown list
-------------------------------------------------------------------------------
-- Category Restriction: every category (the blank row), a category, or one of its
-- subcategories from the submenu that opens on hovering it (Auctioneer-OctoWoW). The choice is
-- kept on the dropdown as auctioneerCategory (0 for every one) and auctioneerSubclass (nil for a
-- whole category), see AuctionFrameSearch_SetCategory. The game's own selection (selectedID)
-- isn't used: it's a row number, checked on whichever list is open, so in the submenu it ticked
-- the wrong rows.
function AuctionFrameSearch_CategoryDropDown_Initialize(level)
	local dropdown = getglobal(UIDROPDOWNMENU_INIT_MENU);
	if (not dropdown) then return; end
	dropdown.selectedID = nil;
	local category = dropdown.auctioneerCategory or 0;
	local subclass = dropdown.auctioneerSubclass;
	local classes = AuctionConfig.classes or {};
	if (level == 2) then
		local cat = UIDROPDOWNMENU_MENU_VALUE;
		local subclasses = classes[cat];
		if (not subclasses) then return; end
		for sub = 1, table.getn(subclasses) do
			UIDropDownMenu_AddButton({
				text = subclasses[sub],
				checked = (category == cat and subclass == sub) and 1 or nil,
				func = AuctionFrameSearch_CategoryDropDownItem_OnClick,
				arg1 = cat,
				arg2 = sub,
				owner = dropdown,
			}, 2);
		end
		return;
	end
	UIDropDownMenu_AddButton({
		text = "",
		checked = (category == 0) and 1 or nil,
		func = AuctionFrameSearch_CategoryDropDownItem_OnClick,
		arg1 = 0,
		owner = dropdown,
	});
	for cat = 1, table.getn(classes) do
		local cdata = classes[cat];
		UIDropDownMenu_AddButton({
			text = cdata.name,
			value = cat,
			hasArrow = (table.getn(cdata) > 0) and 1 or nil,
			checked = (category == cat and not subclass) and 1 or nil,
			func = AuctionFrameSearch_CategoryDropDownItem_OnClick,
			arg1 = cat,
			owner = dropdown,
		});
	end
end

-------------------------------------------------------------------------------
-- An item in a CategoryDrownDown has been clicked
-------------------------------------------------------------------------------
function AuctionFrameSearch_CategoryDropDownItem_OnClick(category, subclass)
	AuctionFrameSearch_SetCategory(this.owner, category, subclass);
	-- a pick in the submenu closes the category list under it too
	CloseDropDownMenus();
end

-- Sets the Category Restriction and its label: the category, or the subcategory, with its
-- category in front when another category has a subcategory of the same name ("Armor:
-- Miscellaneous"). (Auctioneer-OctoWoW)
function AuctionFrameSearch_SetCategory(dropdown, category, subclass)
	local classes = AuctionConfig.classes or {};
	local cdata = classes[category or 0];
	if (not cdata) then category, subclass = 0, nil; end
	if (cdata and not cdata[subclass or 0]) then subclass = nil; end
	dropdown.selectedID = nil;
	dropdown.auctioneerCategory = category;
	dropdown.auctioneerSubclass = subclass;
	local label = "";
	if (cdata) then
		label = cdata.name;
		if (subclass) then
			label = cdata[subclass];
			for other = 1, table.getn(classes) do
				if (other ~= category) then
					for s = 1, table.getn(classes[other]) do
						if (classes[other][s] == label) then label = cdata.name..": "..cdata[subclass]; end
					end
				end
			end
		end
	end
	UIDropDownMenu_SetText(label, dropdown);
end

-- what the filters take: 0, a category number, or { cat, sub } for a subcategory (see
-- categoryMatches in AucFilter.lua)
function AuctionFrameSearch_CategoryFilter(dropdown)
	local category = dropdown.auctioneerCategory or 0;
	local subclass = dropdown.auctioneerSubclass;
	local cdata = AuctionConfig.classes and AuctionConfig.classes[category];
	if (subclass and cdata and cdata[subclass]) then
		return { cat = category, sub = cdata[subclass] };
	end
	return category;
end

-- saved as the old dropdown row (category + 1), with "/subcategory" for a subcategory
function AuctionFrameSearch_CategorySaveText(dropdown)
	local text = tostring((dropdown.auctioneerCategory or 0) + 1);
	if (dropdown.auctioneerSubclass) then text = text.."/"..dropdown.auctioneerSubclass; end
	return text;
end

function AuctionFrameSearch_LoadCategory(dropdown, text)
	local _, _, row, subclass = string.find(text or "", "^(%d+)/?(%d*)$");
	AuctionFrameSearch_SetCategory(dropdown, (tonumber(row) or 1) - 1, tonumber(subclass));
end

-------------------------------------------------------------------------------
-- Initialize the content of a TimeLeft dropdown list
-------------------------------------------------------------------------------
function AuctionFrameSearch_TimeLeftDropDown_Initialize()
	local dropdown = this:GetParent();
	local frame = dropdown:GetParent();
	for index in TIME_LEFT_NAMES do
		local info = {};
		info.text = TIME_LEFT_NAMES[index];
		info.func = AuctionFrameSearch_TimeLeftDropDownItem_OnClick;
		info.owner = dropdown;
		UIDropDownMenu_AddButton(info);
	end
end

-------------------------------------------------------------------------------
-- An item a TimeLeftDrownDown has been clicked
-------------------------------------------------------------------------------
function AuctionFrameSearch_TimeLeftDropDownItem_OnClick()
	local index = this:GetID();
	local dropdown = this.owner;
	AuctioneerDropDownMenu_SetSelectedID(dropdown, index);
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctionFrameSearchBid_SearchButton_OnClick(button)
	local frame = button:GetParent();
	local frameName = frame:GetName();
	local profitMoneyFrame = getglobal(frameName.."MinProfit");
	local percentLessEdit = getglobal(frameName.."MinPercentLessEdit");
	local timeLeftDropDown = getglobal(frameName.."TimeLeftDropDown");

	local minProfit = MoneyInputFrame_GetCopper(profitMoneyFrame);
	local minPercentLess = percentLessEdit:GetNumber();
	local catID = AuctionFrameSearch_CategoryFilter(getglobal(frameName.."CategoryDropDown"));
	local minQuality = (UIDropDownMenu_GetSelectedID(getglobal(frameName.."MinQualityDropDown")) or 1) - 1;
	local box = getglobal(frameName.."SearchEdit");
	local itemName = AuctionFrameSearch_BoxName(box);
	local exact = AuctionFrameSearch_IsPicked(box);

	local timeLeft = Auctioneer.Core.Constants.TimeLeft.Seconds[UIDropDownMenu_GetSelectedID(timeLeftDropDown)];
	local search = frame:GetParent();
	AuctionFrameSearch_Search(search, itemName, function()
		search:SearchBids(minProfit, minPercentLess, timeLeft, catID, minQuality, itemName, exact);
	end);
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctionFrameSearchBuyout_SearchButton_OnClick(button)
	local frame = button:GetParent();
	local frameName = frame:GetName();
	local profitMoneyFrame = getglobal(frame:GetName().."MinProfit");
	local percentLessEdit = getglobal(frame:GetName().."MinPercentLessEdit");

	local minProfit = MoneyInputFrame_GetCopper(profitMoneyFrame);
	local minPercentLess = percentLessEdit:GetNumber();
	local catID = AuctionFrameSearch_CategoryFilter(getglobal(frameName.."CategoryDropDown"));
	local minQuality = (UIDropDownMenu_GetSelectedID(getglobal(frameName.."MinQualityDropDown")) or 1) - 1;
	local box = getglobal(frameName.."SearchEdit");
	local itemName = AuctionFrameSearch_BoxName(box);
	local exact = AuctionFrameSearch_IsPicked(box);

	local search = frame:GetParent();
	AuctionFrameSearch_Search(search, itemName, function()
		search:SearchBuyouts(minProfit, minPercentLess, catID, minQuality, itemName, exact);
	end);
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctionFrameSearchPlain_SearchButton_OnClick(button)
	local frame = button:GetParent();
	local frameName = frame:GetName();

	local maxPrice = MoneyInputFrame_GetCopper(getglobal(frameName.."MaxPrice")) or 0
	local catID = AuctionFrameSearch_CategoryFilter(getglobal(frameName.."CategoryDropDown"));
	local minQuality = (UIDropDownMenu_GetSelectedID(getglobal(frameName.."MinQualityDropDown")) or 1) - 1;
	local box = getglobal(frameName.."SearchEdit");
	local itemName = AuctionFrameSearch_BoxName(box);
	local exact = AuctionFrameSearch_IsPicked(box);

	local search = frame:GetParent();
	AuctionFrameSearch_Search(search, itemName, function()
		search:SearchPlain(maxPrice, catID, minQuality, itemName, exact);
	end);
end

-- the box's item name without spaces around it, or nil
function AuctionFrameSearch_BoxName(box)
	local itemName = string.gsub(box:GetText() or "", "^%s*(.-)%s*$", "%1");
	if (itemName == "") then return nil; end
	return itemName;
end

-- whether the box's name was picked from the suggestions, so it's searched as exactly that item
function AuctionFrameSearch_IsPicked(box)
	return (Auctioneer.Suggest and Auctioneer.Suggest.IsPicked(box)) and true or false;
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctionFrameSearchCompete_SearchButton_OnClick(button)
	local frame = button:GetParent();
	local undercutMoneyFrame = getglobal(frame:GetName().."Undercut");

	local minUndercut = MoneyInputFrame_GetCopper(undercutMoneyFrame);
	frame:GetParent():SearchCompetition(minUndercut);
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctionFrameSearch_OnBidResult(context, bidRequest)
	context.auction.pendingBidCount = context.auction.pendingBidCount - 1;
	if (context.auction.pendingBidCount == 0) then
		if (table.getn(bidRequest.results) == 0) then
			-- No auctions matched.
			context.auction.status = AUCTION_STATUS_NOT_FOUND;
		else
			-- Assume we are now the high bidder on all the matching auctions
			-- until proven otherwise.
			context.auction.status = AUCTION_STATUS_HIGH_BIDDER;
			for _,result in pairs(bidRequest.results) do
				if (result ~= BidResultCodes["BidAccepted"] and
					result ~= BidResultCodes["AlreadyHighBidder"] and
					result ~= BidResultCodes["OwnAuction"]) then
					context.auction.status = AUCTION_STATUS_UNKNOWN;
					break;
				end
			end
		end
		AuctionFrameSearch_UpdateButtons(context.frame);
		ListTemplateScrollFrame_Update(getglobal(context.frame.resultsList:GetName().."ScrollFrame"));
	end
	AuctionFrameSearch_UpdatePendingBidStatus(context.frame);
end

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
function AuctionFrameSearch_GetAuctionAlpha(auction)
	local status = auction.status;
	if (status and (status == AUCTION_STATUS_NOT_FOUND or status == AUCTION_STATUS_HIGH_BIDDER)) then
		return 0.4;
	end
	-- not seen again by a scan that hasn't finished: possibly gone (Auctioneer-OctoWoW)
	if (auction.dirty) then
		return 0.5;
	end
	return 1.0;
end


